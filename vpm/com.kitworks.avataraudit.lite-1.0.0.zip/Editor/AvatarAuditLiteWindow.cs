using UnityEditor;
using UnityEngine;

namespace KitWorks.AvatarAudit
{
    /// <summary>
    /// AvatarAudit Lite — VRChat Avatars 3.0 Performance Rank & Texture VRAM Inspector.
    /// </summary>
    public class AvatarAuditLiteWindow : AvatarAuditWindowBase
    {
        [MenuItem("Tools/KitWorks/AvatarAudit Lite", false, 100)]
        public static void ShowWindow()
        {
            var window = GetWindow<AvatarAuditLiteWindow>("AvatarAudit Lite");
            window.minSize = new Vector2(640f, 520f);
            if (window.TargetAvatar == null && Selection.activeGameObject != null)
            {
                window.TargetAvatar = Selection.activeGameObject;
            }
            window.Show();
        }
    }
}