using System;
using System.Collections.Generic;
using System.Globalization;
using System.Net;
using System.Text;
using UnityEngine;

namespace KitWorks.AvatarAudit
{
    /// <summary>
    /// Exports clipboard summaries, Before/After snapshots, and standalone light-mode editorial HTML reports.
    /// </summary>
    public static class AuditReportExporter
    {
        public static string BuildClipboardSummary(AvatarAuditResult result, AuditLanguage lang)
        {
            if (result == null) return string.Empty;

            var sb = new StringBuilder();
            string platformStr = result.Platform == TargetPlatform.PC ? "PC" : "Android / Quest";
            sb.AppendFormat(CultureInfo.InvariantCulture,
                "[AvatarAudit] {0} | {1} | Overall: {2}\n",
                result.AvatarName,
                platformStr,
                AvatarAuditLocalization.GetRankLabel(result.OverallRank, lang));
            sb.AppendFormat(CultureInfo.InvariantCulture,
                "Texture VRAM: {0:0.1} MB ({1} unique textures) | Issues: {2}\n",
                result.TotalTextureMemoryMB,
                result.UniqueTextureCount,
                result.Issues.Count);
            sb.AppendLine("----------------------------------------");

            for (int i = 0; i < result.Metrics.Count; i++)
            {
                var m = result.Metrics[i];
                if (m.RemovedOnPlatform && m.CurrentValue <= 0) continue;
                string name = AvatarAuditLocalization.GetMetricName(m.Id, lang);
                string val = RankThresholds.FormatMetricValue(m);
                string rank = m.RemovedOnPlatform ? "Disabled" : AvatarAuditLocalization.GetRankLabel(m.Rank, lang);
                sb.AppendFormat(CultureInfo.InvariantCulture, "- {0}: {1} [{2}]\n", name, val, rank);
            }

            if (result.Textures.Count > 0)
            {
                sb.AppendLine("\nTop Textures (VRAM):");
                int topCount = Math.Min(5, result.Textures.Count);
                for (int i = 0; i < topCount; i++)
                {
                    var t = result.Textures[i];
                    sb.AppendFormat(CultureInfo.InvariantCulture,
                        "  {0}. {1} ({2}x{3}, {4}) - {5:0.1} MB\n",
                        i + 1, t.TextureName, t.Width, t.Height, t.FormatName, t.EstimatedMB);
                }
            }

            return sb.ToString();
        }

        public static AuditSnapshot CreateSnapshot(AvatarAuditResult result, string label)
        {
            if (result == null) throw new ArgumentNullException(nameof(result));

            var snap = new AuditSnapshot
            {
                label = string.IsNullOrEmpty(label) ? "Snapshot" : label,
                timestampUtc = result.ScannedAtUtc,
                avatarName = result.AvatarName,
                platformName = result.Platform.ToString(),
                overallRankName = result.OverallRank.ToString(),
                overallRankValue = (int)result.OverallRank,
                totalTextureMemoryMB = Math.Round(result.TotalTextureMemoryMB, 2),
                missingScriptCount = result.MissingScriptCount,
                brokenMaterialCount = result.BrokenMaterialCount,
                duplicateMaterialGroups = result.DuplicateMaterials != null ? result.DuplicateMaterials.Count : 0
            };

            for (int i = 0; i < result.Metrics.Count; i++)
            {
                var m = result.Metrics[i];
                snap.metrics.Add(new SnapshotMetricEntry
                {
                    metricId = m.Id.ToString(),
                    value = Math.Round(m.CurrentValue, 3),
                    rankValue = (int)m.Rank,
                    rankName = m.Rank.ToString()
                });

                switch (m.Id)
                {
                    case MetricId.Triangles: snap.triangles = (int)Math.Round(m.CurrentValue); break;
                    case MetricId.MaterialSlots: snap.materialSlots = (int)Math.Round(m.CurrentValue); break;
                    case MetricId.SkinnedMeshes: snap.skinnedMeshes = (int)Math.Round(m.CurrentValue); break;
                    case MetricId.Bones: snap.bones = (int)Math.Round(m.CurrentValue); break;
                    case MetricId.PhysBoneComponents: snap.physBoneComponents = (int)Math.Round(m.CurrentValue); break;
                    case MetricId.PhysBoneAffectedTransforms: snap.physBoneAffectedTransforms = (int)Math.Round(m.CurrentValue); break;
                    case MetricId.PhysBoneCollisionChecks: snap.physBoneCollisionChecks = (int)Math.Round(m.CurrentValue); break;
                }
            }

            return snap;
        }

        public static string SerializeSnapshotJson(AuditSnapshot snapshot)
        {
            return JsonUtility.ToJson(snapshot, true);
        }

        public static AuditSnapshot DeserializeSnapshotJson(string json)
        {
            if (string.IsNullOrEmpty(json)) return null;
            return JsonUtility.FromJson<AuditSnapshot>(json);
        }

        public static AuditSnapshotDiff CompareSnapshots(AuditSnapshot before, AuditSnapshot after)
        {
            if (before == null) throw new ArgumentNullException(nameof(before));
            if (after == null) throw new ArgumentNullException(nameof(after));

            var diff = new AuditSnapshotDiff
            {
                BeforeLabel = before.label,
                AfterLabel = after.label,
                BeforeOverallRank = (PerformanceRank)before.overallRankValue,
                AfterOverallRank = (PerformanceRank)after.overallRankValue,
                TextureMemoryDeltaMB = after.totalTextureMemoryMB - before.totalTextureMemoryMB,
                TrianglesDelta = after.triangles - before.triangles,
                MaterialSlotsDelta = after.materialSlots - before.materialSlots,
                MissingScriptsDelta = after.missingScriptCount - before.missingScriptCount
            };

            var afterMap = new Dictionary<string, SnapshotMetricEntry>();
            if (after.metrics != null)
            {
                for (int i = 0; i < after.metrics.Count; i++)
                {
                    afterMap[after.metrics[i].metricId] = after.metrics[i];
                }
            }

            if (before.metrics != null)
            {
                for (int i = 0; i < before.metrics.Count; i++)
                {
                    var b = before.metrics[i];
                    SnapshotMetricEntry a;
                    if (!afterMap.TryGetValue(b.metricId, out a)) continue;

                    double delta = a.value - b.value;
                    bool improved = a.rankValue < b.rankValue || delta < -1e-6;
                    bool regressed = a.rankValue > b.rankValue || delta > 1e-6;

                    diff.MetricDiffs.Add(new SnapshotMetricDiff
                    {
                        MetricId = b.metricId,
                        BeforeValue = b.value,
                        AfterValue = a.value,
                        Delta = delta,
                        BeforeRank = (PerformanceRank)b.rankValue,
                        AfterRank = (PerformanceRank)a.rankValue,
                        Improved = improved,
                        Regressed = regressed
                    });
                }
            }

            return diff;
        }

        public static string ExportStandaloneHtml(AvatarAuditResult result, AuditLanguage lang, AuditSnapshotDiff diff = null)
        {
            if (result == null) throw new ArgumentNullException(nameof(result));

            bool isJa = lang == AuditLanguage.Japanese;
            string platformLabel = result.Platform == TargetPlatform.PC ? "PC (Windows)" : "Android / Quest (Mobile)";
            string overallLabel = AvatarAuditLocalization.GetRankLabel(result.OverallRank, lang);
            string rankClass = GetRankCssClass(result.OverallRank);

            var sb = new StringBuilder();
            sb.AppendLine("<!DOCTYPE html>");
            sb.AppendLine(isJa ? "<html lang=\"ja\">" : "<html lang=\"en\">");
            sb.AppendLine("<head>");
            sb.AppendLine("<meta charset=\"utf-8\">");
            sb.AppendLine("<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">");
            sb.AppendFormat("<title>AvatarAudit Report — {0}</title>\n", HtmlEsc(result.AvatarName));
            sb.AppendLine("<style>");
            sb.AppendLine(":root{--paper:#f7f3eb;--card:#fbf9f4;--muted:#efe9dd;--ink:#1e1b18;--soft:#3c3630;--sub:#5a5248;--rule:#d7cebf;--accent:#c1522b;--sage:#396851;--ochre:#b88022;--danger:#b92b27;}");
            sb.AppendLine("*{box-sizing:border-box}body{margin:0;background:var(--paper);color:var(--ink);font-family:'Hiragino Sans','Yu Gothic UI','Segoe UI',system-ui,sans-serif;line-height:1.6;padding:32px 20px}");
            sb.AppendLine(".wrap{max-width:980px;margin:0 auto}");
            sb.AppendLine("header{display:flex;justify-content:space-between;align-items:flex-end;gap:16px;border-bottom:2px solid var(--ink);padding-bottom:16px;margin-bottom:24px;flex-wrap:wrap}");
            sb.AppendLine(".brand{font-size:12px;letter-spacing:.08em;text-transform:uppercase;color:var(--sub);font-weight:700}");
            sb.AppendLine("h1{margin:4px 0 0;font-size:28px;line-height:1.2}");
            sb.AppendLine(".meta{font-size:13px;color:var(--sub);font-family:Consolas,monospace}");
            sb.AppendLine(".summary{display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:14px;margin-bottom:24px}");
            sb.AppendLine(".kpi{background:var(--card);border:1.5px solid var(--ink);border-radius:8px;padding:16px;box-shadow:3px 3px 0 var(--ink)}");
            sb.AppendLine(".kpi .lbl{font-size:12px;color:var(--sub);margin-bottom:6px}.kpi .val{font-size:24px;font-weight:800}");
            sb.AppendLine(".badge{display:inline-block;padding:3px 10px;border-radius:4px;font-size:12px;font-weight:700;letter-spacing:.02em}");
            sb.AppendLine(".r-ex{background:#d7efe1;color:#1b5236}.r-gd{background:#e4f0d5;color:#355d17}.r-md{background:#f7e9c4;color:#6e4f07}.r-pr{background:#f8d8c8;color:#8c2d0c}.r-vp{background:#f5c6c6;color:#7a1212}");
            sb.AppendLine(".panel{background:var(--card);border:1.5px solid var(--rule);border-radius:8px;padding:20px;margin-bottom:20px}");
            sb.AppendLine("h2{margin:0 0 12px;font-size:18px;border-bottom:1px solid var(--rule);padding-bottom:8px}");
            sb.AppendLine("table{width:100%;border-collapse:collapse;font-size:13.5px}th,td{padding:8px 10px;border-bottom:1px solid var(--rule);text-align:left}");
            sb.AppendLine("th{background:var(--muted);font-size:12px;color:var(--soft);font-weight:700}.num{font-family:Consolas,monospace;text-align:right}");
            sb.AppendLine(".bar-bg{height:8px;background:var(--muted);border-radius:4px;overflow:hidden;min-width:90px}.bar-fill{height:100%;background:var(--accent)}");
            sb.AppendLine(".rec{border-left:4px solid var(--accent);background:var(--paper);padding:10px 14px;margin-bottom:10px;border-radius:0 6px 6px 0}");
            sb.AppendLine(".rec-title{font-weight:700;margin-bottom:2px}.rec-sub{font-size:13px;color:var(--soft)}");
            sb.AppendLine("footer{margin-top:28px;font-size:12px;color:var(--sub);display:flex;justify-content:space-between;border-top:1px solid var(--rule);padding-top:12px}");
            sb.AppendLine("</style>");
            sb.AppendLine("</head>");
            sb.AppendLine("<body><div class=\"wrap\">");

            // Header
            sb.AppendLine("<header>");
            sb.AppendLine("<div>");
            sb.AppendLine("<div class=\"brand\">KitWorks Lab / AvatarAudit Diagnostic Report</div>");
            sb.AppendFormat("<h1>{0}</h1>\n", HtmlEsc(result.AvatarName));
            sb.AppendLine("</div>");
            sb.AppendFormat("<div class=\"meta\">{0} &middot; {1}</div>\n", HtmlEsc(platformLabel), HtmlEsc(result.ScannedAtUtc));
            sb.AppendLine("</header>");

            // KPI row
            sb.AppendLine("<section class=\"summary\">");
            sb.AppendFormat("<div class=\"kpi\"><div class=\"lbl\">{0}</div><div class=\"val\"><span class=\"badge {1}\">{2}</span></div></div>\n",
                HtmlEsc(AvatarAuditLocalization.Get("ui.overall_rank", lang)), rankClass, HtmlEsc(overallLabel));
            sb.AppendFormat("<div class=\"kpi\"><div class=\"lbl\">{0}</div><div class=\"val\">{1:0.1} MB</div></div>\n",
                HtmlEsc(AvatarAuditLocalization.Get("ui.vram_total", lang)), result.TotalTextureMemoryMB);
            sb.AppendFormat("<div class=\"kpi\"><div class=\"lbl\">{0}</div><div class=\"val\">{1}</div></div>\n",
                HtmlEsc(isJa ? "テクスチャ枚数" : "Unique Textures"), result.UniqueTextureCount);
            sb.AppendFormat("<div class=\"kpi\"><div class=\"lbl\">{0}</div><div class=\"val\">{1}</div></div>\n",
                HtmlEsc(AvatarAuditLocalization.Get("ui.issues_found", lang)), result.Issues.Count);
            sb.AppendLine("</section>");

            // Before / After Diff if supplied
            if (diff != null)
            {
                sb.AppendLine("<section class=\"panel\">");
                sb.AppendFormat("<h2>{0} ({1} &rarr; {2})</h2>\n",
                    isJa ? "最適化前後比較" : "Before / After Diff",
                    HtmlEsc(diff.BeforeLabel),
                    HtmlEsc(diff.AfterLabel));
                sb.AppendFormat("<p><strong>{0}:</strong> {1} &rarr; {2} | <strong>VRAM:</strong> {3:+0.0;-0.0;0.0} MB | <strong>Triangles:</strong> {4:+#,0;-#,0;0} | <strong>Missing Scripts:</strong> {5:+#,0;-#,0;0}</p>\n",
                    isJa ? "総合ランク" : "Overall Rank",
                    HtmlEsc(diff.BeforeOverallRank.ToString()),
                    HtmlEsc(diff.AfterOverallRank.ToString()),
                    diff.TextureMemoryDeltaMB,
                    diff.TrianglesDelta,
                    diff.MissingScriptsDelta);
                sb.AppendLine("</section>");
            }

            // Recommendations
            if (result.Recommendations.Count > 0)
            {
                sb.AppendLine("<section class=\"panel\">");
                sb.AppendFormat("<h2>{0}</h2>\n", HtmlEsc(AvatarAuditLocalization.Get("ui.recommendations", lang)));
                for (int i = 0; i < result.Recommendations.Count; i++)
                {
                    var rec = result.Recommendations[i];
                    sb.AppendLine("<div class=\"rec\">");
                    sb.AppendFormat("<div class=\"rec-title\">[P{0}] {1}</div>\n", rec.Priority, HtmlEsc(rec.Title));
                    sb.AppendFormat("<div class=\"rec-sub\">{0} — {1}</div>\n", HtmlEsc(rec.Detail), HtmlEsc(rec.EstimatedImpact));
                    sb.AppendLine("</div>");
                }
                sb.AppendLine("</section>");
            }

            // Performance Rank Breakdown Table
            sb.AppendLine("<section class=\"panel\">");
            sb.AppendFormat("<h2>{0}</h2>\n", HtmlEsc(AvatarAuditLocalization.Get("ui.tab.rank", lang)));
            sb.AppendLine("<table><thead><tr>");
            sb.AppendFormat("<th>{0}</th><th class=\"num\">{1}</th><th>{2}</th><th class=\"num\">{3}</th>",
                HtmlEsc(AvatarAuditLocalization.Get("ui.col.metric", lang)),
                HtmlEsc(AvatarAuditLocalization.Get("ui.col.value", lang)),
                HtmlEsc(AvatarAuditLocalization.Get("ui.col.rank", lang)),
                HtmlEsc(AvatarAuditLocalization.Get("ui.col.limits", lang)));
            sb.AppendLine("</tr></thead><tbody>");

            for (int i = 0; i < result.Metrics.Count; i++)
            {
                var m = result.Metrics[i];
                string limits = m.RemovedOnPlatform
                    ? AvatarAuditLocalization.Get("ui.removed_on_mobile", lang)
                    : string.Format(CultureInfo.InvariantCulture, "{0} / {1} / {2} / {3}", m.Threshold.Excellent, m.Threshold.Good, m.Threshold.Medium, m.Threshold.Poor);
                string badge = m.RemovedOnPlatform
                    ? "<span class=\"badge r-ex\">Disabled</span>"
                    : string.Format("<span class=\"badge {0}\">{1}</span>", GetRankCssClass(m.Rank), HtmlEsc(AvatarAuditLocalization.GetRankLabel(m.Rank, lang)));

                sb.AppendFormat("<tr><td>{0}</td><td class=\"num\">{1}</td><td>{2}</td><td class=\"num\">{3}</td></tr>\n",
                    HtmlEsc(AvatarAuditLocalization.GetMetricName(m.Id, lang)),
                    HtmlEsc(RankThresholds.FormatMetricValue(m)),
                    badge,
                    HtmlEsc(limits));
            }
            sb.AppendLine("</tbody></table></section>");

            // Texture VRAM Ranking
            sb.AppendLine("<section class=\"panel\">");
            sb.AppendFormat("<h2>{0} ({1:0.1} MB)</h2>\n", HtmlEsc(AvatarAuditLocalization.Get("ui.tab.textures", lang)), result.TotalTextureMemoryMB);
            if (result.Textures.Count == 0)
            {
                sb.AppendFormat("<p>{0}</p>\n", HtmlEsc(AvatarAuditLocalization.Get("ui.no_textures", lang)));
            }
            else
            {
                sb.AppendLine("<table><thead><tr><th>Texture</th><th>Resolution</th><th>Format</th><th>Mip</th><th class=\"num\">VRAM</th><th>Share</th></tr></thead><tbody>");
                double maxTex = Math.Max(0.1, result.Textures[0].EstimatedMB);
                for (int i = 0; i < result.Textures.Count; i++)
                {
                    var t = result.Textures[i];
                    int pct = (int)Math.Min(100, Math.Round((t.EstimatedMB / maxTex) * 100.0));
                    sb.AppendFormat(CultureInfo.InvariantCulture,
                        "<tr><td>{0}</td><td>{1}x{2}</td><td>{3}</td><td>{4}</td><td class=\"num\">{5:0.2} MB</td><td><div class=\"bar-bg\"><div class=\"bar-fill\" style=\"width:{6}%\"></div></div></td></tr>\n",
                        HtmlEsc(t.TextureName), t.Width, t.Height, HtmlEsc(t.FormatName), t.MipMapsEnabled ? "On" : "Off", t.EstimatedMB, pct);
                }
                sb.AppendLine("</tbody></table>");
            }
            sb.AppendLine("</section>");

            // Footer
            sb.AppendLine("<footer><span>Generated by AvatarAudit — KitWorks Lab</span><span>VRChat Avatars 3.0 Performance Ranking Specification</span></footer>");
            sb.AppendLine("</div></body></html>");
            return sb.ToString();
        }

        private static string GetRankCssClass(PerformanceRank rank)
        {
            switch (rank)
            {
                case PerformanceRank.Excellent: return "r-ex";
                case PerformanceRank.Good: return "r-gd";
                case PerformanceRank.Medium: return "r-md";
                case PerformanceRank.Poor: return "r-pr";
                default: return "r-vp";
            }
        }

        private static string HtmlEsc(string input)
        {
            return WebUtility.HtmlEncode(input ?? string.Empty);
        }
    }
}