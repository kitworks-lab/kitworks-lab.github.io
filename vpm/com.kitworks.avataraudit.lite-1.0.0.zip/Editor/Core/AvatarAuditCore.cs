using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;
using UnityEditor;
using UnityEngine;
using UnityEngine.Animations;

namespace KitWorks.AvatarAudit
{
    /// <summary>
    /// Core Unity scene/prefab scanner for VRChat Avatars 3.0 Performance Rank,
    /// Texture VRAM, and structural diagnostics.
    /// </summary>
    public static class AvatarAuditCore
    {
        private static readonly HumanBodyBones[] EssentialHumanoidBones =
        {
            HumanBodyBones.Hips,
            HumanBodyBones.Spine,
            HumanBodyBones.Head,
            HumanBodyBones.LeftUpperArm,
            HumanBodyBones.LeftLowerArm,
            HumanBodyBones.LeftHand,
            HumanBodyBones.RightUpperArm,
            HumanBodyBones.RightLowerArm,
            HumanBodyBones.RightHand,
            HumanBodyBones.LeftUpperLeg,
            HumanBodyBones.LeftLowerLeg,
            HumanBodyBones.LeftFoot,
            HumanBodyBones.RightUpperLeg,
            HumanBodyBones.RightLowerLeg,
            HumanBodyBones.RightFoot
        };

        public static AvatarAuditResult RunAudit(GameObject avatarRoot, TargetPlatform platform, AuditLanguage lang)
        {
            if (avatarRoot == null) throw new ArgumentNullException(nameof(avatarRoot));

            var result = new AvatarAuditResult
            {
                AvatarName = avatarRoot.name,
                ScannedAtUtc = DateTime.UtcNow.ToString("yyyy-MM-dd HH:mm:ss UTC", CultureInfo.InvariantCulture),
                Platform = platform
            };

            Transform[] allTransforms = avatarRoot.GetComponentsInChildren<Transform>(true);

            int triangles = 0;
            bool meshReadWriteDisabled = false;
            var uniqueBones = new HashSet<Transform>();
            int materialSlots = 0;
            var referencedMaterials = new List<Material>();
            var materialToRenderersCount = new Dictionary<Material, int>();

            bool hasBounds = false;
            Bounds combinedBounds = new Bounds(avatarRoot.transform.position, Vector3.zero);

            SkinnedMeshRenderer[] skinnedMeshes = avatarRoot.GetComponentsInChildren<SkinnedMeshRenderer>(true);
            for (int i = 0; i < skinnedMeshes.Length; i++)
            {
                SkinnedMeshRenderer smr = skinnedMeshes[i];
                if (smr == null) continue;

                Mesh mesh = smr.sharedMesh;
                if (mesh != null)
                {
                    if (!mesh.isReadable)
                    {
                        meshReadWriteDisabled = true;
                        result.Issues.Add(new DiagnosticIssue
                        {
                            Severity = DiagnosticSeverity.Error,
                            Category = DiagnosticCategory.MeshReadWrite,
                            ObjectPath = GetRelativePath(avatarRoot.transform, smr.transform),
                            Title = lang == AuditLanguage.Japanese ? "Mesh Read/Write オフ" : "Mesh Read/Write Disabled",
                            Detail = string.Format("Mesh '{0}' has Read/Write disabled (forces Very Poor in VRChat).", mesh.name),
                            ActionHint = lang == AuditLanguage.Japanese ? "FBX Import Settings で Read/Write を有効化" : "Enable Read/Write in Model Importer"
                        });
                    }
                    triangles += CountMeshTriangles(mesh);

                    int bsCount = mesh.blendShapeCount;
                    int zeroWeightCount = 0;
                    for (int b = 0; b < bsCount; b++)
                    {
                        if (Mathf.Abs(smr.GetBlendShapeWeight(b)) < 0.001f)
                        {
                            zeroWeightCount++;
                        }
                    }
                    result.UnusedBlendShapeCount += zeroWeightCount;
                }

                Transform[] bones = smr.bones;
                if (bones != null)
                {
                    for (int b = 0; b < bones.Length; b++)
                    {
                        if (bones[b] != null) uniqueBones.Add(bones[b]);
                    }
                }

                Material[] mats = smr.sharedMaterials;
                if (mats != null)
                {
                    materialSlots += mats.Length;
                    CollectRendererMaterials(avatarRoot.transform, smr.transform, mats, referencedMaterials, materialToRenderersCount, result, lang);
                }

                AccumulateBounds(ref hasBounds, ref combinedBounds, smr.bounds);
            }

            MeshRenderer[] meshRenderers = avatarRoot.GetComponentsInChildren<MeshRenderer>(true);
            for (int i = 0; i < meshRenderers.Length; i++)
            {
                MeshRenderer mr = meshRenderers[i];
                if (mr == null) continue;

                MeshFilter mf = mr.GetComponent<MeshFilter>();
                if (mf != null && mf.sharedMesh != null)
                {
                    Mesh mesh = mf.sharedMesh;
                    if (!mesh.isReadable)
                    {
                        meshReadWriteDisabled = true;
                        result.Issues.Add(new DiagnosticIssue
                        {
                            Severity = DiagnosticSeverity.Error,
                            Category = DiagnosticCategory.MeshReadWrite,
                            ObjectPath = GetRelativePath(avatarRoot.transform, mr.transform),
                            Title = lang == AuditLanguage.Japanese ? "Mesh Read/Write オフ" : "Mesh Read/Write Disabled",
                            Detail = string.Format("Mesh '{0}' has Read/Write disabled (forces Very Poor in VRChat).", mesh.name),
                            ActionHint = lang == AuditLanguage.Japanese ? "FBX Import Settings で Read/Write を有効化" : "Enable Read/Write in Model Importer"
                        });
                    }
                    triangles += CountMeshTriangles(mesh);
                }

                Material[] mats = mr.sharedMaterials;
                if (mats != null)
                {
                    materialSlots += mats.Length;
                    CollectRendererMaterials(avatarRoot.transform, mr.transform, mats, referencedMaterials, materialToRenderersCount, result, lang);
                }

                AccumulateBounds(ref hasBounds, ref combinedBounds, mr.bounds);
            }

            ParticleSystem[] particleSystems = avatarRoot.GetComponentsInChildren<ParticleSystem>(true);
            int totalParticlesActive = 0;
            for (int i = 0; i < particleSystems.Length; i++)
            {
                ParticleSystem ps = particleSystems[i];
                if (ps == null) continue;
                totalParticlesActive += ps.main.maxParticles;
                materialSlots += ps.trails.enabled ? 2 : 1;

                ParticleSystemRenderer psr = ps.GetComponent<ParticleSystemRenderer>();
                if (psr != null && psr.sharedMaterials != null)
                {
                    CollectRendererMaterials(avatarRoot.transform, ps.transform, psr.sharedMaterials, referencedMaterials, materialToRenderersCount, result, lang);
                }
            }

            TrailRenderer[] trailRenderers = avatarRoot.GetComponentsInChildren<TrailRenderer>(true);
            for (int i = 0; i < trailRenderers.Length; i++)
            {
                if (trailRenderers[i] == null) continue;
                materialSlots += 1;
                if (trailRenderers[i].sharedMaterials != null)
                {
                    CollectRendererMaterials(avatarRoot.transform, trailRenderers[i].transform, trailRenderers[i].sharedMaterials, referencedMaterials, materialToRenderersCount, result, lang);
                }
            }

            LineRenderer[] lineRenderers = avatarRoot.GetComponentsInChildren<LineRenderer>(true);
            for (int i = 0; i < lineRenderers.Length; i++)
            {
                if (lineRenderers[i] == null) continue;
                materialSlots += 1;
                if (lineRenderers[i].sharedMaterials != null)
                {
                    CollectRendererMaterials(avatarRoot.transform, lineRenderers[i].transform, lineRenderers[i].sharedMaterials, referencedMaterials, materialToRenderersCount, result, lang);
                }
            }

            Animator[] animators = avatarRoot.GetComponentsInChildren<Animator>(true);
            CheckHumanoidRig(avatarRoot, animators, result, lang);

            Light[] lights = avatarRoot.GetComponentsInChildren<Light>(true);
            AudioSource[] audioSources = avatarRoot.GetComponentsInChildren<AudioSource>(true);
            Cloth[] cloths = avatarRoot.GetComponentsInChildren<Cloth>(true);
            int totalClothVertices = 0;
            for (int i = 0; i < cloths.Length; i++)
            {
                if (cloths[i] != null && cloths[i].vertices != null)
                {
                    totalClothVertices += cloths[i].vertices.Length;
                }
            }
            Collider[] physicsColliders = avatarRoot.GetComponentsInChildren<Collider>(true);
            Rigidbody[] rigidbodies = avatarRoot.GetComponentsInChildren<Rigidbody>(true);

            Component[] allComponents = avatarRoot.GetComponentsInChildren<Component>(true);
            int unityConstraintCount = 0;
            var constraintTransforms = new HashSet<Transform>();
            for (int i = 0; i < allComponents.Length; i++)
            {
                if (allComponents[i] is IConstraint)
                {
                    unityConstraintCount++;
                    if (allComponents[i] != null) constraintTransforms.Add(allComponents[i].transform);
                }
            }

            VRCSDKScanData vrcData = VRCSDKReflectionBridge.Scan(avatarRoot);
            result.HasVRCSDK = vrcData.HasVRCSDK;
            result.HasAvatarDescriptor = vrcData.HasAvatarDescriptor;

            int totalConstraints = unityConstraintCount + vrcData.VRCConstraintCount;
            int constraintDepth = EstimateConstraintDepth(constraintTransforms);

            for (int i = 0; i < allTransforms.Length; i++)
            {
                GameObject go = allTransforms[i].gameObject;
                int missing = GameObjectUtility.GetMonoBehavioursWithMissingScriptCount(go);
                if (missing > 0)
                {
                    result.MissingScriptCount += missing;
                    result.Issues.Add(new DiagnosticIssue
                    {
                        Severity = DiagnosticSeverity.Error,
                        Category = DiagnosticCategory.MissingScript,
                        ObjectPath = GetRelativePath(avatarRoot.transform, go.transform),
                        Title = lang == AuditLanguage.Japanese ? "Missing Script 検出" : "Missing Script Detected",
                        Detail = string.Format("{0} missing script component(s) on '{1}'.", missing, go.name),
                        ActionHint = lang == AuditLanguage.Japanese ? "Proの一括削除またはInspectorから削除" : "Remove via Pro Cleaner or Inspector"
                    });
                }
            }

            List<TextureAuditItem> textureItems = AnalyzeTextures(referencedMaterials);
            textureItems.Sort((a, b) => b.EstimatedBytes.CompareTo(a.EstimatedBytes));
            result.Textures = textureItems;
            result.UniqueTextureCount = textureItems.Count;

            long totalTexBytes = 0;
            for (int i = 0; i < textureItems.Count; i++)
            {
                totalTexBytes += textureItems[i].EstimatedBytes;
                if (textureItems[i].Width >= 4096 || textureItems[i].Height >= 4096)
                {
                    result.Issues.Add(new DiagnosticIssue
                    {
                        Severity = DiagnosticSeverity.Warning,
                        Category = DiagnosticCategory.TextureSettings,
                        ObjectPath = textureItems[i].AssetPath,
                        Title = lang == AuditLanguage.Japanese ? "4K以上の高解像度テクスチャ" : "4K+ Texture Detected",
                        Detail = string.Format("{0} ({1}x{2}, {3:0.1} MB)", textureItems[i].TextureName, textureItems[i].Width, textureItems[i].Height, textureItems[i].EstimatedMB),
                        ActionHint = lang == AuditLanguage.Japanese ? "Max Size を 2048px 以下に下げると大幅に軽量化" : "Downscale Max Size to 2048px or 1024px"
                    });
                }
            }
            result.TotalTextureMemoryBytes = totalTexBytes;
            result.TotalTextureMemoryMB = TextureMemoryCalculator.BytesToMB(totalTexBytes);

            result.DuplicateMaterials = FindDuplicateMaterials(materialToRenderersCount);
            for (int i = 0; i < result.DuplicateMaterials.Count; i++)
            {
                var grp = result.DuplicateMaterials[i];
                result.Issues.Add(new DiagnosticIssue
                {
                    Severity = DiagnosticSeverity.Info,
                    Category = DiagnosticCategory.DuplicateMaterial,
                    ObjectPath = grp.MaterialPaths.Count > 0 ? grp.MaterialPaths[0] : "",
                    Title = lang == AuditLanguage.Japanese ? "重複マテリアル候補" : "Duplicate Material Group",
                    Detail = string.Format("{0} materials share identical shader '{1}' and textures ({2}).",
                        grp.MaterialNames.Count, grp.ShaderName, string.Join(", ", grp.MaterialNames)),
                    ActionHint = lang == AuditLanguage.Japanese ? "Pro の重複マテリアル統合で1つにまとめ可能" : "Merge with Pro Duplicate Material Merger"
                });
            }

            result.Bounds = new BoundsAuditInfo
            {
                SizeX = hasBounds ? combinedBounds.size.x : 0f,
                SizeY = hasBounds ? combinedBounds.size.y : 0f,
                SizeZ = hasBounds ? combinedBounds.size.z : 0f
            };
            result.HasMeshReadWriteDisabled = meshReadWriteDisabled;

            result.Metrics.Add(RankThresholds.EvaluateMetric(platform, MetricId.Triangles, triangles, meshReadWriteDisabled, meshReadWriteDisabled ? "Mesh Read/Write Disabled" : null));
            result.Metrics.Add(RankThresholds.EvaluateMetric(platform, MetricId.TextureMemoryMB, result.TotalTextureMemoryMB));
            result.Metrics.Add(RankThresholds.EvaluateMetric(platform, MetricId.SkinnedMeshes, skinnedMeshes.Length));
            result.Metrics.Add(RankThresholds.EvaluateMetric(platform, MetricId.BasicMeshes, meshRenderers.Length));
            result.Metrics.Add(RankThresholds.EvaluateMetric(platform, MetricId.MaterialSlots, materialSlots));
            result.Metrics.Add(RankThresholds.EvaluateMetric(platform, MetricId.Bones, uniqueBones.Count));
            result.Metrics.Add(RankThresholds.EvaluateMetric(platform, MetricId.PhysBoneComponents, vrcData.PhysBoneComponents));
            result.Metrics.Add(RankThresholds.EvaluateMetric(platform, MetricId.PhysBoneAffectedTransforms, vrcData.PhysBoneAffectedTransforms));
            result.Metrics.Add(RankThresholds.EvaluateMetric(platform, MetricId.PhysBoneColliders, vrcData.PhysBoneColliders));
            result.Metrics.Add(RankThresholds.EvaluateMetric(platform, MetricId.PhysBoneCollisionChecks, vrcData.PhysBoneCollisionChecks));
            result.Metrics.Add(RankThresholds.EvaluateMetric(platform, MetricId.Contacts, vrcData.Contacts));
            result.Metrics.Add(RankThresholds.EvaluateMetric(platform, MetricId.ConstraintCount, totalConstraints));
            result.Metrics.Add(RankThresholds.EvaluateMetric(platform, MetricId.ConstraintDepth, constraintDepth));
            result.Metrics.Add(RankThresholds.EvaluateMetric(platform, MetricId.Animators, animators.Length));
            result.Metrics.Add(RankThresholds.EvaluateMetric(platform, MetricId.Lights, lights.Length));
            result.Metrics.Add(RankThresholds.EvaluateMetric(platform, MetricId.AudioSources, audioSources.Length));
            result.Metrics.Add(RankThresholds.EvaluateMetric(platform, MetricId.ParticleSystems, particleSystems.Length));
            result.Metrics.Add(RankThresholds.EvaluateMetric(platform, MetricId.TotalParticlesActive, totalParticlesActive));
            result.Metrics.Add(RankThresholds.EvaluateMetric(platform, MetricId.TrailRenderers, trailRenderers.Length));
            result.Metrics.Add(RankThresholds.EvaluateMetric(platform, MetricId.LineRenderers, lineRenderers.Length));
            result.Metrics.Add(RankThresholds.EvaluateMetric(platform, MetricId.Cloths, cloths.Length));
            result.Metrics.Add(RankThresholds.EvaluateMetric(platform, MetricId.TotalClothVertices, totalClothVertices));
            result.Metrics.Add(RankThresholds.EvaluateMetric(platform, MetricId.PhysicsColliders, physicsColliders.Length));
            result.Metrics.Add(RankThresholds.EvaluateMetric(platform, MetricId.PhysicsRigidbodies, rigidbodies.Length));
            result.Metrics.Add(RankThresholds.EvaluateBounds(platform, result.Bounds));

            if (platform == TargetPlatform.Mobile)
            {
                for (int i = 0; i < result.Metrics.Count; i++)
                {
                    var m = result.Metrics[i];
                    if (m.HardCapExceeded)
                    {
                        result.Issues.Add(new DiagnosticIssue
                        {
                            Severity = DiagnosticSeverity.Error,
                            Category = DiagnosticCategory.MobileHardCap,
                            ObjectPath = avatarRoot.name,
                            Title = lang == AuditLanguage.Japanese ? "Mobile ハード上限超過" : "Mobile Hard Cap Exceeded",
                            Detail = string.Format("{0}: {1} (Max {2})", AvatarAuditLocalization.GetMetricName(m.Id, lang), RankThresholds.FormatMetricValue(m), m.Threshold.Poor),
                            ActionHint = lang == AuditLanguage.Japanese ? "超過するとQuest上で関連コンポーネントが全削除されます" : "VRChat strips these components completely on Quest/Mobile"
                        });
                    }
                    else if (m.RemovedOnPlatform && m.CurrentValue > 0)
                    {
                        result.Issues.Add(new DiagnosticIssue
                        {
                            Severity = DiagnosticSeverity.Warning,
                            Category = DiagnosticCategory.MobileHardCap,
                            ObjectPath = avatarRoot.name,
                            Title = lang == AuditLanguage.Japanese ? "Mobile 非対応コンポーネント" : "Component Disabled on Mobile",
                            Detail = string.Format("{0}: {1}", AvatarAuditLocalization.GetMetricName(m.Id, lang), RankThresholds.FormatMetricValue(m)),
                            ActionHint = lang == AuditLanguage.Japanese ? "Quest版ビルドでは自動で無効化されます" : "Automatically removed on Android/Quest builds"
                        });
                    }
                }
            }

            result.OverallRank = RankThresholds.ComputeOverallRank(result.Metrics, meshReadWriteDisabled);
            result.Recommendations = RankThresholds.BuildRecommendations(result, lang);
            return result;
        }
        public static int CountMeshTriangles(Mesh mesh)
        {
            if (mesh == null) return 0;
            int total = 0;
            int subMeshCount = mesh.subMeshCount;
            if (subMeshCount <= 0)
            {
                int[] tris = mesh.triangles;
                return tris != null ? tris.Length / 3 : 0;
            }

            for (int s = 0; s < subMeshCount; s++)
            {
                total += (int)(mesh.GetIndexCount(s) / 3);
            }
            return total;
        }

        private static void CollectRendererMaterials(
            Transform root,
            Transform rendererTransform,
            Material[] materials,
            List<Material> referencedMaterials,
            Dictionary<Material, int> usageCounts,
            AvatarAuditResult result,
            AuditLanguage lang)
        {
            for (int m = 0; m < materials.Length; m++)
            {
                Material mat = materials[m];
                if (mat == null)
                {
                    result.BrokenMaterialCount++;
                    result.Issues.Add(new DiagnosticIssue
                    {
                        Severity = DiagnosticSeverity.Error,
                        Category = DiagnosticCategory.BrokenMaterial,
                        ObjectPath = GetRelativePath(root, rendererTransform),
                        Title = lang == AuditLanguage.Japanese ? "空のマテリアルスロット" : "Missing Material Slot",
                        Detail = string.Format("Material slot #{0} on '{1}' is null.", m, rendererTransform.name),
                        ActionHint = lang == AuditLanguage.Japanese ? "マテリアルを割り当てるか不要スロットを削除" : "Assign a valid material or remove unused slot"
                    });
                    continue;
                }

                if (mat.shader == null || string.Equals(mat.shader.name, "Hidden/InternalErrorShader", StringComparison.Ordinal))
                {
                    result.BrokenMaterialCount++;
                    result.Issues.Add(new DiagnosticIssue
                    {
                        Severity = DiagnosticSeverity.Error,
                        Category = DiagnosticCategory.BrokenMaterial,
                        ObjectPath = GetRelativePath(root, rendererTransform),
                        Title = lang == AuditLanguage.Japanese ? "壊れたシェーダー (ピンク表示)" : "Broken / Error Shader",
                        Detail = string.Format("Material '{0}' uses missing or error shader.", mat.name),
                        ActionHint = lang == AuditLanguage.Japanese ? "lilToon / Poiyomi 等の正しいシェーダーを再指定" : "Reassign a valid shader to this material"
                    });
                }

                int existing;
                if (usageCounts.TryGetValue(mat, out existing))
                {
                    usageCounts[mat] = existing + 1;
                }
                else
                {
                    usageCounts[mat] = 1;
                    referencedMaterials.Add(mat);
                }
            }
        }

        private static List<TextureAuditItem> AnalyzeTextures(List<Material> materials)
        {
            var itemsByKey = new Dictionary<string, TextureAuditItem>();
            var list = new List<TextureAuditItem>();

            for (int i = 0; i < materials.Count; i++)
            {
                Material mat = materials[i];
                if (mat == null || mat.shader == null) continue;

                string[] propNames = mat.GetTexturePropertyNames();
                if (propNames == null) continue;

                for (int p = 0; p < propNames.Length; p++)
                {
                    Texture tex = mat.GetTexture(propNames[p]);
                    Texture2D tex2D = tex as Texture2D;
                    if (tex2D == null) continue;

                    string assetPath = AssetDatabase.GetAssetPath(tex2D);
                    string key = !string.IsNullOrEmpty(assetPath) ? assetPath : ("inst:" + tex2D.GetInstanceID());

                    TextureAuditItem item;
                    if (!itemsByKey.TryGetValue(key, out item))
                    {
                        bool hasMips = tex2D.mipmapCount > 1;
                        double bpp = TextureMemoryCalculator.GetBitsPerPixel(tex2D.format);
                        long bytes = TextureMemoryCalculator.CalculateBytes(tex2D.width, tex2D.height, bpp, hasMips);

                        int maxTexSize = Math.Max(tex2D.width, tex2D.height);
                        bool crunched = false;
                        int crunchQuality = 50;
                        string compressionMode = "Compressed";
                        bool isNormal = false;

                        if (!string.IsNullOrEmpty(assetPath))
                        {
                            TextureImporter importer = AssetImporter.GetAtPath(assetPath) as TextureImporter;
                            if (importer != null)
                            {
                                maxTexSize = importer.maxTextureSize;
                                crunched = importer.crunchedCompression;
                                crunchQuality = importer.compressionQuality;
                                compressionMode = importer.textureCompression.ToString();
                                isNormal = importer.textureType == TextureImporterType.NormalMap;
                                hasMips = importer.mipmapEnabled;
                                bytes = TextureMemoryCalculator.CalculateBytes(tex2D.width, tex2D.height, bpp, hasMips);
                            }
                        }

                        item = new TextureAuditItem
                        {
                            AssetPath = assetPath ?? string.Empty,
                            TextureName = tex2D.name,
                            Width = tex2D.width,
                            Height = tex2D.height,
                            OriginalSourceWidth = tex2D.width,
                            OriginalSourceHeight = tex2D.height,
                            MipMapsEnabled = hasMips,
                            FormatName = tex2D.format.ToString(),
                            BitsPerPixel = bpp,
                            EstimatedBytes = bytes,
                            EstimatedMB = TextureMemoryCalculator.BytesToMB(bytes),
                            MaxTextureSizeSetting = maxTexSize,
                            CrunchCompressed = crunched,
                            CrunchQuality = crunchQuality,
                            CompressionMode = compressionMode,
                            IsNormalMap = isNormal,
                            IsReadable = tex2D.isReadable,
                            UsageCount = 0
                        };

                        itemsByKey[key] = item;
                        list.Add(item);
                    }

                    item.UsageCount++;
                    if (!item.UsedByMaterials.Contains(mat.name))
                    {
                        item.UsedByMaterials.Add(mat.name);
                    }
                }
            }

            return list;
        }

        public static List<DuplicateMaterialGroup> FindDuplicateMaterials(Dictionary<Material, int> materialUsageCounts)
        {
            var matsBySig = new Dictionary<string, List<Material>>();

            foreach (var kv in materialUsageCounts)
            {
                Material mat = kv.Key;
                if (mat == null || mat.shader == null) continue;

                string path = AssetDatabase.GetAssetPath(mat);
                if (string.IsNullOrEmpty(path)) continue;

                string sig = BuildMaterialSignature(mat);
                List<Material> bucket;
                if (!matsBySig.TryGetValue(sig, out bucket))
                {
                    bucket = new List<Material>();
                    matsBySig[sig] = bucket;
                }
                bucket.Add(mat);
            }

            var result = new List<DuplicateMaterialGroup>();
            foreach (var kv in matsBySig)
            {
                if (kv.Value.Count < 2) continue;

                var grp = new DuplicateMaterialGroup
                {
                    Signature = kv.Key,
                    ShaderName = kv.Value[0].shader != null ? kv.Value[0].shader.name : "Unknown",
                    PotentialMaterialsSaved = kv.Value.Count - 1
                };

                for (int i = 0; i < kv.Value.Count; i++)
                {
                    Material mat = kv.Value[i];
                    grp.MaterialNames.Add(mat.name);
                    grp.MaterialPaths.Add(AssetDatabase.GetAssetPath(mat));
                    int slots;
                    if (materialUsageCounts.TryGetValue(mat, out slots))
                    {
                        grp.RendererSlotCount += slots;
                    }
                }

                result.Add(grp);
            }

            result.Sort((a, b) => b.PotentialMaterialsSaved.CompareTo(a.PotentialMaterialsSaved));
            return result;
        }

        public static string BuildMaterialSignature(Material mat)
        {
            if (mat == null) return string.Empty;
            var sb = new StringBuilder();
            sb.Append(mat.shader != null ? mat.shader.name : "NULL_SHADER");
            sb.Append('|');
            sb.Append(mat.renderQueue);
            sb.Append('|');

            if (mat.HasProperty("_Color"))
            {
                Color c = mat.GetColor("_Color");
                sb.AppendFormat(CultureInfo.InvariantCulture, "C:{0:0.###},{1:0.###},{2:0.###},{3:0.###}|", c.r, c.g, c.b, c.a);
            }

            string[] texProps = mat.GetTexturePropertyNames();
            if (texProps != null)
            {
                Array.Sort(texProps, StringComparer.Ordinal);
                for (int i = 0; i < texProps.Length; i++)
                {
                    Texture t = mat.GetTexture(texProps[i]);
                    if (t == null) continue;
                    string path = AssetDatabase.GetAssetPath(t);
                    sb.Append(texProps[i]);
                    sb.Append('=');
                    sb.Append(!string.IsNullOrEmpty(path) ? path : t.name);
                    sb.Append(';');
                }
            }

            string[] keywords = mat.shaderKeywords;
            if (keywords != null && keywords.Length > 0)
            {
                Array.Sort(keywords, StringComparer.Ordinal);
                sb.Append("|KW:");
                sb.Append(string.Join(",", keywords));
            }

            return sb.ToString();
        }

        private static void CheckHumanoidRig(GameObject avatarRoot, Animator[] animators, AvatarAuditResult result, AuditLanguage lang)
        {
            Animator rootAnim = avatarRoot.GetComponent<Animator>();
            if (rootAnim == null)
            {
                result.Issues.Add(new DiagnosticIssue
                {
                    Severity = DiagnosticSeverity.Warning,
                    Category = DiagnosticCategory.HumanoidRig,
                    ObjectPath = avatarRoot.name,
                    Title = lang == AuditLanguage.Japanese ? "ルートに Animator がありません" : "Missing Root Animator",
                    Detail = lang == AuditLanguage.Japanese
                        ? "アバターのルート GameObject に Animator が付いていません。"
                        : "Avatar root GameObject has no Animator component.",
                    ActionHint = lang == AuditLanguage.Japanese ? "Humanoid Avatar を割り当てた Animator を追加" : "Attach an Animator with a Humanoid Avatar"
                });
                return;
            }

            if (rootAnim.avatar == null || !rootAnim.isHuman)
            {
                result.Issues.Add(new DiagnosticIssue
                {
                    Severity = DiagnosticSeverity.Warning,
                    Category = DiagnosticCategory.HumanoidRig,
                    ObjectPath = avatarRoot.name,
                    Title = lang == AuditLanguage.Japanese ? "Humanoid リグ未設定" : "Non-Humanoid Avatar",
                    Detail = lang == AuditLanguage.Japanese
                        ? "Root Animator の Avatar が Humanoid として認識されていません。"
                        : "Root Animator does not reference a valid Humanoid Avatar.",
                    ActionHint = lang == AuditLanguage.Japanese ? "FBX の Rig タブを Humanoid に設定" : "Configure FBX Rig as Humanoid"
                });
                return;
            }

            var missingBones = new List<string>();
            for (int i = 0; i < EssentialHumanoidBones.Length; i++)
            {
                Transform bone = rootAnim.GetBoneTransform(EssentialHumanoidBones[i]);
                if (bone == null)
                {
                    missingBones.Add(EssentialHumanoidBones[i].ToString());
                }
            }

            if (missingBones.Count > 0)
            {
                result.Issues.Add(new DiagnosticIssue
                {
                    Severity = DiagnosticSeverity.Warning,
                    Category = DiagnosticCategory.HumanoidRig,
                    ObjectPath = avatarRoot.name,
                    Title = lang == AuditLanguage.Japanese ? "必須 Humanoid ボーン不足" : "Missing Essential Humanoid Bones",
                    Detail = string.Join(", ", missingBones),
                    ActionHint = lang == AuditLanguage.Japanese ? "Avatar Configure でボーン割り当てを確認" : "Check bone mapping in Avatar Configuration"
                });
            }
        }

        private static int EstimateConstraintDepth(HashSet<Transform> constraintTransforms)
        {
            if (constraintTransforms == null || constraintTransforms.Count == 0) return 0;
            int maxDepth = 0;
            foreach (Transform t in constraintTransforms)
            {
                int depth = 1;
                Transform cursor = t != null ? t.parent : null;
                while (cursor != null)
                {
                    if (constraintTransforms.Contains(cursor)) depth++;
                    cursor = cursor.parent;
                }
                if (depth > maxDepth) maxDepth = depth;
            }
            return maxDepth;
        }

        private static void AccumulateBounds(ref bool hasBounds, ref Bounds combined, Bounds next)
        {
            if (!hasBounds)
            {
                combined = next;
                hasBounds = true;
            }
            else
            {
                combined.Encapsulate(next);
            }
        }

        public static string GetRelativePath(Transform root, Transform target)
        {
            if (target == null) return string.Empty;
            if (root == null || target == root) return target.name;

            var parts = new Stack<string>();
            Transform current = target;
            while (current != null && current != root)
            {
                parts.Push(current.name);
                current = current.parent;
            }
            return string.Join("/", parts);
        }
    }
}