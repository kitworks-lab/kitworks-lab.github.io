using System;
using System.Collections.Generic;
using UnityEditor;

namespace KitWorks.AvatarAudit
{
    public static class AvatarAuditLocalization
    {
        private const string PrefKey = "KitWorks.AvatarAudit.Language";

        private static readonly Dictionary<string, string> Ja = new Dictionary<string, string>
        {
            { "app.title.lite", "AvatarAudit Lite" },
            { "app.title.pro", "AvatarAudit Pro" },
            { "app.subtitle", "VRChat Avatars 3.0 パフォーマンスランク & VRAM 診断" },
            { "ui.target_avatar", "対象アバター" },
            { "ui.platform", "評価プラットフォーム" },
            { "ui.platform.pc", "PC (Windows)" },
            { "ui.platform.mobile", "Android / Quest (Mobile)" },
            { "ui.scan", "診断を実行" },
            { "ui.copy_summary", "要約をコピー" },
            { "ui.export_html", "HTMLレポート出力" },
            { "ui.overall_rank", "総合ランク" },
            { "ui.vram_total", "テクスチャVRAM合計" },
            { "ui.issues_found", "検出された問題" },
            { "ui.select_avatar_hint", "Hierarchy 上のアバター Root を指定して「診断を実行」を押してください。" },
            { "ui.vrcsdk_detected", "VRCSDK 検出済み (PhysBone / Contact / Descriptor 計測有効)" },
            { "ui.vrcsdk_not_detected", "VRCSDK 未導入 (標準 Unity コンポーネントのみで計測)" },
            { "ui.tab.rank", "ランク詳細" },
            { "ui.tab.textures", "VRAM ランキング" },
            { "ui.tab.issues", "診断・不具合" },
            { "ui.tab.optimize", "一括最適化 (Pro)" },
            { "ui.tab.cleanup", "クリーンアップ (Pro)" },
            { "ui.tab.diff", "前後比較 (Pro)" },
            { "ui.col.metric", "項目" },
            { "ui.col.value", "現在値" },
            { "ui.col.rank", "ランク" },
            { "ui.col.limits", "目安 (Ex / Gd / Md / Pr)" },
            { "ui.col.note", "メモ" },
            { "ui.removed_on_mobile", "Mobileでは無効化" },
            { "ui.hardcap_exceeded", "Mobile上限超過(全削除)" },
            { "ui.no_textures", "使用中のテクスチャは見つかりませんでした。" },
            { "ui.no_issues", "問題は見つかりませんでした。" },
            { "ui.select_asset", "選択" },
            { "ui.preset", "最適化プリセット" },
            { "ui.preset.pc_balanced", "PC バランス (最大 2048px / Crunch 75%)" },
            { "ui.preset.pc_light", "PC 軽量 (最大 1024px / Crunch 65%)" },
            { "ui.preset.quest", "Quest / Android 安全 (最大 1024px / ASTC 6x6)" },
            { "ui.preview_savings", "適用前プレビュー: {0:0.0} MB → {1:0.0} MB (削減 {2:0.0} MB / 対象 {3}枚)" },
            { "ui.apply_optimize", "一括最適化を適用 (バックアップ自動保存)" },
            { "ui.restore_backup", "元のインポート設定に戻す" },
            { "ui.no_backup", "保存済みバックアップなし" },
            { "ui.backup_available", "バックアップ保存済み: {0} ({1}枚)" },
            { "ui.clean_missing_scripts", "Missing Script を一括削除 ({0}件)" },
            { "ui.merge_dup_materials", "重複マテリアルを統合 ({0}グループ)" },
            { "ui.save_before", "Before スナップショット保存" },
            { "ui.save_after", "After スナップショット保存" },
            { "ui.diff_hint", "最適化前に「Before」、適用後に「After」を保存すると差分を比較できます。" },
            { "ui.copied_clipboard", "診断サマリーをクリップボードにコピーしました。" },
            { "ui.recommendations", "優先改善ポイント" },
            { "ui.pro_upsell", "Pro版では、1クリック一括VRAM最適化（ロールバック対応）、Missing Script削除、重複マテリアル統合、前後比較、HTMLレポート出力が使えます。" },

            { "rank.Excellent", "Excellent" },
            { "rank.Good", "Good" },
            { "rank.Medium", "Medium" },
            { "rank.Poor", "Poor" },
            { "rank.VeryPoor", "Very Poor" },

            { "metric.Triangles", "ポリゴン数 (Triangles)" },
            { "metric.TextureMemoryMB", "テクスチャ VRAM" },
            { "metric.SkinnedMeshes", "Skinned Mesh 数" },
            { "metric.BasicMeshes", "Mesh Renderer 数" },
            { "metric.MaterialSlots", "マテリアルスロット数" },
            { "metric.Bones", "ボーン数" },
            { "metric.PhysBoneComponents", "PhysBone コンポーネント" },
            { "metric.PhysBoneAffectedTransforms", "PhysBone 影響ボーン数" },
            { "metric.PhysBoneColliders", "PhysBone コライダー" },
            { "metric.PhysBoneCollisionChecks", "PhysBone 衝突判定回数" },
            { "metric.Contacts", "Contact 数" },
            { "metric.ConstraintCount", "Constraint 数" },
            { "metric.ConstraintDepth", "Constraint 階層深度" },
            { "metric.Animators", "Animator 数" },
            { "metric.Lights", "Light 数" },
            { "metric.AudioSources", "AudioSource 数" },
            { "metric.ParticleSystems", "ParticleSystem 数" },
            { "metric.TotalParticlesActive", "最大同時パーティクル数" },
            { "metric.TrailRenderers", "TrailRenderer 数" },
            { "metric.LineRenderers", "LineRenderer 数" },
            { "metric.Cloths", "Cloth 数" },
            { "metric.TotalClothVertices", "Cloth 頂点数" },
            { "metric.PhysicsColliders", "物理コライダー数" },
            { "metric.PhysicsRigidbodies", "Rigidbody 数" },
            { "metric.BoundsSize", "バウンディングボックス" },

            { "rec.mesh_rw.title", "Mesh Read/Write が無効なメッシュがあります (Very Poor 強制)" },
            { "rec.mesh_rw.detail", "VRChatでは Read/Write がオフのメッシュが1つでもあると、ポリゴン数に関わらず強制的に Very Poor になります。" },
            { "rec.mesh_rw.impact", "FBXインポート設定で Read/Write を有効にするだけで解消します。" },
            { "rec.hardcap.detail", "{0} が {1} で Mobile のハード上限 ({2}) を超えています。VRChat 側で該当コンポーネントが一括削除されます。" },
            { "rec.verypoor.detail", "{0} が {1} で Poor 上限 ({2}) を {3} 超過しています。" },
            { "rec.poor.detail", "{0} が {1} です。Medium ({2} 以下) まで下げると表示制限に掛かりにくくなります。" },
            { "rec.metric.title", "{0} ({1})" },
            { "rec.missing_scripts.title", "Missing Script が残っています" },
            { "rec.missing_scripts.detail", "アバター内に {0} 件の Missing Script が含まれています。アップロードエラーや不要な警告の原因になります。" },
            { "rec.missing_scripts.impact", "不要コンポーネントの削除でプロジェクトを健全化できます。" },
            { "rec.dup_mat.title", "同一設定の重複マテリアルがあります" },
            { "rec.dup_mat.detail", "{0} グループで完全一致するマテリアルが見つかりました（最大 {1} マテリアル削減可能）。" },
            { "rec.dup_mat.impact", "ドローコールや管理負荷を減らせます。" },

            { "advice.vram.pc", "4Kテクスチャを 2048px または 1024px に下げると VRAM を 75%〜93% 削減できます。" },
            { "advice.vram.mobile", "Quest向けは Max Size 1024px + Android ASTC 6x6 に設定すると大幅に削減できます。" },
            { "advice.triangles", "非表示メッシュや衣装の重複部分を削除、または Decimate で削減してください。" },
            { "advice.materials", "同一シェーダーのマテリアル統合やメッシュ結合（AAO / MeshBaker等）が有効です。" },
            { "advice.physbones", "揺れもののルート統合、末端ボーンの Ignore Transforms 指定、コライダー整理が効きます。" },
            { "advice.bones", "使っていない補助ボーンや衣装側の未使用ボーンを整理してください。" },
            { "advice.general", "不要な非アクティブオブジェクトもランクに加算されるため削除を検討してください。" }
        };

        private static readonly Dictionary<string, string> En = new Dictionary<string, string>
        {
            { "app.title.lite", "AvatarAudit Lite" },
            { "app.title.pro", "AvatarAudit Pro" },
            { "app.subtitle", "VRChat Avatars 3.0 Performance Rank & VRAM Diagnostics" },
            { "ui.target_avatar", "Target Avatar" },
            { "ui.platform", "Target Platform" },
            { "ui.platform.pc", "PC (Windows)" },
            { "ui.platform.mobile", "Android / Quest (Mobile)" },
            { "ui.scan", "Run Audit" },
            { "ui.copy_summary", "Copy Summary" },
            { "ui.export_html", "Export HTML Report" },
            { "ui.overall_rank", "Overall Rank" },
            { "ui.vram_total", "Estimated Texture VRAM" },
            { "ui.issues_found", "Diagnostic Issues" },
            { "ui.select_avatar_hint", "Assign an avatar root GameObject from the Hierarchy and click Run Audit." },
            { "ui.vrcsdk_detected", "VRCSDK detected (PhysBone / Contact / Descriptor scanning active)" },
            { "ui.vrcsdk_not_detected", "VRCSDK not found (scanning standard Unity components only)" },
            { "ui.tab.rank", "Rank Breakdown" },
            { "ui.tab.textures", "Texture VRAM" },
            { "ui.tab.issues", "Diagnostics" },
            { "ui.tab.optimize", "Batch Optimizer (Pro)" },
            { "ui.tab.cleanup", "Cleanup Tools (Pro)" },
            { "ui.tab.diff", "Before / After (Pro)" },
            { "ui.col.metric", "Metric" },
            { "ui.col.value", "Current" },
            { "ui.col.rank", "Rank" },
            { "ui.col.limits", "Limits (Ex / Gd / Md / Pr)" },
            { "ui.col.note", "Note" },
            { "ui.removed_on_mobile", "Disabled on Mobile" },
            { "ui.hardcap_exceeded", "Mobile Hard Cap (Stripped)" },
            { "ui.no_textures", "No textures referenced by this avatar." },
            { "ui.no_issues", "No diagnostic issues detected." },
            { "ui.select_asset", "Ping" },
            { "ui.preset", "Optimization Preset" },
            { "ui.preset.pc_balanced", "PC Balanced (2048px Max / Crunch 75%)" },
            { "ui.preset.pc_light", "PC Lightweight (1024px Max / Crunch 65%)" },
            { "ui.preset.quest", "Quest / Android Safe (1024px Max / ASTC 6x6)" },
            { "ui.preview_savings", "Estimated Impact: {0:0.0} MB -> {1:0.0} MB (Save {2:0.0} MB across {3} textures)" },
            { "ui.apply_optimize", "Apply Batch Optimization (Auto-Backup)" },
            { "ui.restore_backup", "Restore Original Import Settings" },
            { "ui.no_backup", "No saved backup yet" },
            { "ui.backup_available", "Backup ready: {0} ({1} textures)" },
            { "ui.clean_missing_scripts", "Remove All Missing Scripts ({0})" },
            { "ui.merge_dup_materials", "Merge Duplicate Materials ({0} groups)" },
            { "ui.save_before", "Save Before Snapshot" },
            { "ui.save_after", "Save After Snapshot" },
            { "ui.diff_hint", "Capture a Before snapshot, apply optimizations, then capture After to inspect the delta." },
            { "ui.copied_clipboard", "Audit summary copied to clipboard." },
            { "ui.recommendations", "Prioritized Fixes" },
            { "ui.pro_upsell", "Pro adds 1-click Batch VRAM Optimization with JSON rollback, Missing Script Cleaner, Duplicate Material Merger, Before/After Snapshot Diff, and HTML Diagnostic Reports." },

            { "rank.Excellent", "Excellent" },
            { "rank.Good", "Good" },
            { "rank.Medium", "Medium" },
            { "rank.Poor", "Poor" },
            { "rank.VeryPoor", "Very Poor" },

            { "metric.Triangles", "Triangles (Polygons)" },
            { "metric.TextureMemoryMB", "Texture Memory" },
            { "metric.SkinnedMeshes", "Skinned Meshes" },
            { "metric.BasicMeshes", "Basic Meshes" },
            { "metric.MaterialSlots", "Material Slots" },
            { "metric.Bones", "Bones" },
            { "metric.PhysBoneComponents", "PhysBone Components" },
            { "metric.PhysBoneAffectedTransforms", "PhysBone Affected Transforms" },
            { "metric.PhysBoneColliders", "PhysBone Colliders" },
            { "metric.PhysBoneCollisionChecks", "PhysBone Collision Checks" },
            { "metric.Contacts", "Contacts" },
            { "metric.ConstraintCount", "Constraint Count" },
            { "metric.ConstraintDepth", "Constraint Depth" },
            { "metric.Animators", "Animators" },
            { "metric.Lights", "Lights" },
            { "metric.AudioSources", "Audio Sources" },
            { "metric.ParticleSystems", "Particle Systems" },
            { "metric.TotalParticlesActive", "Total Particles Active" },
            { "metric.TrailRenderers", "Trail Renderers" },
            { "metric.LineRenderers", "Line Renderers" },
            { "metric.Cloths", "Cloths" },
            { "metric.TotalClothVertices", "Cloth Vertices" },
            { "metric.PhysicsColliders", "Physics Colliders" },
            { "metric.PhysicsRigidbodies", "Physics Rigidbodies" },
            { "metric.BoundsSize", "Bounds Size" },

            { "rec.mesh_rw.title", "Mesh Read/Write Disabled (Forces Very Poor)" },
            { "rec.mesh_rw.detail", "VRChat downgrades any avatar containing a mesh with Read/Write disabled directly to Very Poor." },
            { "rec.mesh_rw.impact", "Enable Read/Write in the model importer settings to restore true rank." },
            { "rec.hardcap.detail", "{0} is {1}, exceeding the Mobile hard cap ({2}). VRChat strips these components completely on Quest/Android." },
            { "rec.verypoor.detail", "{0} is {1}, exceeding the Poor limit ({2}) by {3}." },
            { "rec.poor.detail", "{0} is {1}. Bringing it under {2} reaches Medium rank." },
            { "rec.metric.title", "{0} ({1})" },
            { "rec.missing_scripts.title", "Missing Scripts Detected" },
            { "rec.missing_scripts.detail", "Found {0} missing script component(s) in the avatar hierarchy. These can break builds or spam console warnings." },
            { "rec.missing_scripts.impact", "Clean missing references before uploading." },
            { "rec.dup_mat.title", "Duplicate Materials Found" },
            { "rec.dup_mat.detail", "{0} duplicate group(s) share identical shader and properties (up to {1} redundant materials)." },
            { "rec.dup_mat.impact", "Consolidating identical materials reduces draw-call overhead and clutter." },

            { "advice.vram.pc", "Downscaling 4K textures to 2048px or 1024px cuts GPU VRAM by 75% to 93.75%." },
            { "advice.vram.mobile", "Set Max Size to 1024px with Android ASTC 6x6 override for Quest/Mobile budgets." },
            { "advice.triangles", "Remove hidden interior geometry/unused outfits or decimate high-poly accessories." },
            { "advice.materials", "Merge identical materials or combine static outfit meshes to cut material slots." },
            { "advice.physbones", "Consolidate PhysBone chains, add Ignore Transforms on leaf bones, and prune redundant colliders." },
            { "advice.bones", "Prune unused helper bones and unskinned accessory armatures." },
            { "advice.general", "Disabled GameObjects still count toward VRChat performance rank; remove unused toggles." }
        };

        public static AuditLanguage CurrentLanguage
        {
            get { return (AuditLanguage)EditorPrefs.GetInt(PrefKey, (int)AuditLanguage.Japanese); }
            set { EditorPrefs.SetInt(PrefKey, (int)value); }
        }

        public static string Get(string key, AuditLanguage lang)
        {
            var dict = lang == AuditLanguage.Japanese ? Ja : En;
            string value;
            if (dict.TryGetValue(key, out value)) return value;
            if (En.TryGetValue(key, out value)) return value;
            return key;
        }

        public static string Get(string key)
        {
            return Get(key, CurrentLanguage);
        }

        public static string GetMetricName(MetricId id, AuditLanguage lang)
        {
            return Get("metric." + id.ToString(), lang);
        }

        public static string GetRankLabel(PerformanceRank rank, AuditLanguage lang)
        {
            return Get("rank." + rank.ToString(), lang);
        }

        public static IReadOnlyCollection<string> AllKeysJapanese
        {
            get { return Ja.Keys; }
        }

        public static IReadOnlyCollection<string> AllKeysEnglish
        {
            get { return En.Keys; }
        }
    }
}