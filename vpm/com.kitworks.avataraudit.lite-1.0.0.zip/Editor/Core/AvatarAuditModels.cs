using System;
using System.Collections.Generic;

namespace KitWorks.AvatarAudit
{
    public enum PerformanceRank
    {
        Excellent = 0,
        Good = 1,
        Medium = 2,
        Poor = 3,
        VeryPoor = 4
    }

    public enum TargetPlatform
    {
        PC = 0,
        Mobile = 1
    }

    public enum MetricId
    {
        Triangles,
        TextureMemoryMB,
        SkinnedMeshes,
        BasicMeshes,
        MaterialSlots,
        Bones,
        PhysBoneComponents,
        PhysBoneAffectedTransforms,
        PhysBoneColliders,
        PhysBoneCollisionChecks,
        Contacts,
        ConstraintCount,
        ConstraintDepth,
        Animators,
        Lights,
        AudioSources,
        ParticleSystems,
        TotalParticlesActive,
        TrailRenderers,
        LineRenderers,
        Cloths,
        TotalClothVertices,
        PhysicsColliders,
        PhysicsRigidbodies,
        BoundsSize
    }

    public enum MetricBlockingEffect
    {
        None,
        Fallback,
        StripPhysBonesAndContacts,
        StripLights,
        StripParticles,
        StripConstraints,
        StripAudio,
        StripCloth,
        StripPhysics
    }

    public enum DiagnosticSeverity
    {
        Info = 0,
        Warning = 1,
        Error = 2
    }

    public enum DiagnosticCategory
    {
        MissingScript,
        BrokenMaterial,
        MeshReadWrite,
        UnusedBlendShape,
        DuplicateMaterial,
        HumanoidRig,
        MobileHardCap,
        TextureSettings
    }

    public enum OptimizationPreset
    {
        PCBalanced2KCrunch = 0,
        PCLightweight1KCrunch = 1,
        QuestSafe1KASTC6x6 = 2
    }

    public enum AuditLanguage
    {
        Japanese = 0,
        English = 1
    }

    public sealed class MetricThreshold
    {
        public MetricId Id;
        public double Excellent;
        public double Good;
        public double Medium;
        public double Poor;
        public bool IsInteger;
        public bool IsHardCapOnMobile;
        public bool IsRemovedOnMobile;
        public MetricBlockingEffect BlockingEffect;
        public string Unit;

        public MetricThreshold(
            MetricId id,
            double excellent,
            double good,
            double medium,
            double poor,
            bool isInteger,
            MetricBlockingEffect blockingEffect,
            string unit = "",
            bool isHardCapOnMobile = false,
            bool isRemovedOnMobile = false)
        {
            Id = id;
            Excellent = excellent;
            Good = good;
            Medium = medium;
            Poor = poor;
            IsInteger = isInteger;
            BlockingEffect = blockingEffect;
            Unit = unit ?? "";
            IsHardCapOnMobile = isHardCapOnMobile;
            IsRemovedOnMobile = isRemovedOnMobile;
        }

        public double GetLimitForRank(PerformanceRank rank)
        {
            switch (rank)
            {
                case PerformanceRank.Excellent: return Excellent;
                case PerformanceRank.Good: return Good;
                case PerformanceRank.Medium: return Medium;
                case PerformanceRank.Poor: return Poor;
                default: return double.PositiveInfinity;
            }
        }
    }

    public sealed class MetricEvaluation
    {
        public MetricId Id;
        public double CurrentValue;
        public bool IsInteger;
        public PerformanceRank Rank;
        public MetricThreshold Threshold;
        public double ExcessOverNextBetterRank;
        public double ExcessOverPoor;
        public double HeadroomToNextWorseRank;
        public bool HardCapExceeded;
        public bool RemovedOnPlatform;
        public string ForcedReason;
        public string ExtraDisplayValue;
    }

    public sealed class TextureAuditItem
    {
        public string AssetPath;
        public string TextureName;
        public int Width;
        public int Height;
        public int OriginalSourceWidth;
        public int OriginalSourceHeight;
        public bool MipMapsEnabled;
        public string FormatName;
        public double BitsPerPixel;
        public long EstimatedBytes;
        public double EstimatedMB;
        public int MaxTextureSizeSetting;
        public bool CrunchCompressed;
        public int CrunchQuality;
        public string CompressionMode;
        public bool IsNormalMap;
        public bool IsReadable;
        public int UsageCount;
        public List<string> UsedByMaterials = new List<string>();
    }

    public sealed class DiagnosticIssue
    {
        public DiagnosticSeverity Severity;
        public DiagnosticCategory Category;
        public string ObjectPath;
        public string Title;
        public string Detail;
        public string ActionHint;
    }

    public sealed class DuplicateMaterialGroup
    {
        public string Signature;
        public string ShaderName;
        public List<string> MaterialPaths = new List<string>();
        public List<string> MaterialNames = new List<string>();
        public int RendererSlotCount;
        public int PotentialMaterialsSaved;
    }

    public sealed class OptimizationRecommendation
    {
        public int Priority;
        public MetricId MetricId;
        public string Title;
        public string Detail;
        public string EstimatedImpact;
    }

    public sealed class BoundsAuditInfo
    {
        public float SizeX;
        public float SizeY;
        public float SizeZ;

        public double MaxAxis
        {
            get { return Math.Max(SizeX, Math.Max(SizeY, SizeZ)); }
        }
    }

    public sealed class AvatarAuditResult
    {
        public string AvatarName;
        public string ScannedAtUtc;
        public TargetPlatform Platform;
        public PerformanceRank OverallRank;
        public bool HasMeshReadWriteDisabled;
        public bool HasVRCSDK;
        public bool HasAvatarDescriptor;
        public double TotalTextureMemoryMB;
        public long TotalTextureMemoryBytes;
        public int UniqueTextureCount;
        public int MissingScriptCount;
        public int BrokenMaterialCount;
        public int UnusedBlendShapeCount;
        public BoundsAuditInfo Bounds = new BoundsAuditInfo();
        public List<MetricEvaluation> Metrics = new List<MetricEvaluation>();
        public List<TextureAuditItem> Textures = new List<TextureAuditItem>();
        public List<DiagnosticIssue> Issues = new List<DiagnosticIssue>();
        public List<DuplicateMaterialGroup> DuplicateMaterials = new List<DuplicateMaterialGroup>();
        public List<OptimizationRecommendation> Recommendations = new List<OptimizationRecommendation>();
    }

    [Serializable]
    public sealed class SnapshotMetricEntry
    {
        public string metricId;
        public double value;
        public int rankValue;
        public string rankName;
    }

    [Serializable]
    public sealed class AuditSnapshot
    {
        public string label;
        public string timestampUtc;
        public string avatarName;
        public string platformName;
        public string overallRankName;
        public int overallRankValue;
        public double totalTextureMemoryMB;
        public int triangles;
        public int materialSlots;
        public int skinnedMeshes;
        public int bones;
        public int physBoneComponents;
        public int physBoneAffectedTransforms;
        public int physBoneCollisionChecks;
        public int missingScriptCount;
        public int brokenMaterialCount;
        public int duplicateMaterialGroups;
        public List<SnapshotMetricEntry> metrics = new List<SnapshotMetricEntry>();
    }

    public sealed class SnapshotMetricDiff
    {
        public string MetricId;
        public double BeforeValue;
        public double AfterValue;
        public double Delta;
        public PerformanceRank BeforeRank;
        public PerformanceRank AfterRank;
        public bool Improved;
        public bool Regressed;
    }

    public sealed class AuditSnapshotDiff
    {
        public string BeforeLabel;
        public string AfterLabel;
        public PerformanceRank BeforeOverallRank;
        public PerformanceRank AfterOverallRank;
        public double TextureMemoryDeltaMB;
        public int TrianglesDelta;
        public int MaterialSlotsDelta;
        public int MissingScriptsDelta;
        public List<SnapshotMetricDiff> MetricDiffs = new List<SnapshotMetricDiff>();
    }

    public sealed class TextureOptimizationPlanItem
    {
        public string AssetPath;
        public string TextureName;
        public int CurrentWidth;
        public int CurrentHeight;
        public int TargetWidth;
        public int TargetHeight;
        public string CurrentFormat;
        public string TargetFormat;
        public bool CurrentMipMaps;
        public bool TargetMipMaps;
        public long CurrentBytes;
        public long EstimatedNewBytes;
        public long SavedBytes;
        public bool WillChange;
        public string SkipReason;
        public int TargetMaxSize;
        public bool EnableCrunch;
        public int CrunchQuality;
        public bool ApplyAndroidASTC;
    }

    public sealed class TextureOptimizationPlan
    {
        public OptimizationPreset Preset;
        public long TotalCurrentBytes;
        public long TotalEstimatedNewBytes;
        public long TotalSavedBytes;
        public double TotalCurrentMB;
        public double TotalEstimatedNewMB;
        public double TotalSavedMB;
        public int AffectedTextureCount;
        public List<TextureOptimizationPlanItem> Items = new List<TextureOptimizationPlanItem>();
    }

    [Serializable]
    public sealed class TextureBackupEntry
    {
        public string assetPath;
        public int maxTextureSize;
        public bool crunchedCompression;
        public int compressionQuality;
        public int textureCompression;
        public bool mipmapEnabled;
        public bool androidOverridden;
        public int androidMaxTextureSize;
        public int androidFormat;
        public int androidCompressionQuality;
        public bool standaloneOverridden;
        public int standaloneMaxTextureSize;
        public int standaloneFormat;
        public bool standaloneCrunched;
        public int standaloneCompressionQuality;
    }

    [Serializable]
    public sealed class TextureBackupManifest
    {
        public string createdAtUtc;
        public string avatarName;
        public string presetName;
        public List<TextureBackupEntry> entries = new List<TextureBackupEntry>();
    }
}