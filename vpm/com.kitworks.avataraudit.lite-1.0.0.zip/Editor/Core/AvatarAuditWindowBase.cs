using System;
using System.Globalization;
using UnityEditor;
using UnityEngine;

namespace KitWorks.AvatarAudit
{
    /// <summary>
    /// AvatarAudit Lite — VRChat Avatars 3.0 Performance Rank & Texture VRAM Inspector.
    /// </summary>
    public abstract class AvatarAuditWindowBase : EditorWindow
    {
        protected GameObject TargetAvatar;
        protected TargetPlatform SelectedPlatform = TargetPlatform.PC;
        protected AvatarAuditResult LastResult;
        protected int SelectedTab;
        protected Vector2 ScrollPos;
        protected string StatusBanner = string.Empty;

        

        protected virtual bool IsProEdition
        {
            get { return false; }
        }

        protected virtual string[] GetTabTitles(AuditLanguage lang)
        {
            return new[]
            {
                AvatarAuditLocalization.Get("ui.tab.rank", lang),
                AvatarAuditLocalization.Get("ui.tab.textures", lang),
                AvatarAuditLocalization.Get("ui.tab.issues", lang)
            };
        }

        protected virtual void OnGUI()
        {
            AuditLanguage lang = AvatarAuditLocalization.CurrentLanguage;

            DrawHeader(lang);
            DrawToolbar(lang);

            if (!string.IsNullOrEmpty(StatusBanner))
            {
                EditorGUILayout.HelpBox(StatusBanner, MessageType.Info);
            }

            if (LastResult == null)
            {
                EditorGUILayout.Space(8f);
                EditorGUILayout.HelpBox(AvatarAuditLocalization.Get("ui.select_avatar_hint", lang), MessageType.None);
                DrawFooter(lang);
                return;
            }

            DrawSummaryCards(lang);

            EditorGUILayout.Space(6f);
            string[] tabs = GetTabTitles(lang);
            SelectedTab = GUILayout.Toolbar(SelectedTab, tabs, GUILayout.Height(26f));
            EditorGUILayout.Space(6f);

            ScrollPos = EditorGUILayout.BeginScrollView(ScrollPos);
            DrawActiveTab(lang);
            EditorGUILayout.EndScrollView();

            DrawFooter(lang);
        }

        protected virtual void DrawActiveTab(AuditLanguage lang)
        {
            switch (SelectedTab)
            {
                case 0: DrawRankTab(lang); break;
                case 1: DrawTexturesTab(lang); break;
                case 2: DrawIssuesTab(lang); break;
            }
        }

        protected void DrawHeader(AuditLanguage lang)
        {
            EditorGUILayout.BeginHorizontal(EditorStyles.toolbar);
            string titleKey = IsProEdition ? "app.title.pro" : "app.title.lite";
            GUILayout.Label(AvatarAuditLocalization.Get(titleKey, lang), EditorStyles.boldLabel);
            GUILayout.FlexibleSpace();

            bool isJa = lang == AuditLanguage.Japanese;
            if (GUILayout.Toggle(isJa, "JP", EditorStyles.toolbarButton, GUILayout.Width(34f)) && !isJa)
            {
                AvatarAuditLocalization.CurrentLanguage = AuditLanguage.Japanese;
                RefreshRecommendationsLanguage();
            }
            if (GUILayout.Toggle(!isJa, "EN", EditorStyles.toolbarButton, GUILayout.Width(34f)) && isJa)
            {
                AvatarAuditLocalization.CurrentLanguage = AuditLanguage.English;
                RefreshRecommendationsLanguage();
            }
            EditorGUILayout.EndHorizontal();

            EditorGUILayout.LabelField(AvatarAuditLocalization.Get("app.subtitle", lang), EditorStyles.miniLabel);
        }

        protected virtual void DrawToolbar(AuditLanguage lang)
        {
            EditorGUILayout.BeginVertical(EditorStyles.helpBox);
            TargetAvatar = (GameObject)EditorGUILayout.ObjectField(
                AvatarAuditLocalization.Get("ui.target_avatar", lang),
                TargetAvatar,
                typeof(GameObject),
                true);

            EditorGUILayout.BeginHorizontal();
            string[] platformLabels =
            {
                AvatarAuditLocalization.Get("ui.platform.pc", lang),
                AvatarAuditLocalization.Get("ui.platform.mobile", lang)
            };
            int nextPlatform = EditorGUILayout.Popup(
                AvatarAuditLocalization.Get("ui.platform", lang),
                (int)SelectedPlatform,
                platformLabels);
            if (nextPlatform != (int)SelectedPlatform)
            {
                SelectedPlatform = (TargetPlatform)nextPlatform;
                if (TargetAvatar != null && LastResult != null)
                {
                    RunAuditNow();
                }
            }
            EditorGUILayout.EndHorizontal();

            EditorGUILayout.Space(4f);
            EditorGUILayout.BeginHorizontal();
            GUI.enabled = TargetAvatar != null;
            if (GUILayout.Button(AvatarAuditLocalization.Get("ui.scan", lang), GUILayout.Height(28f)))
            {
                RunAuditNow();
            }

            GUI.enabled = LastResult != null;
            if (GUILayout.Button(AvatarAuditLocalization.Get("ui.copy_summary", lang), GUILayout.Height(28f), GUILayout.Width(140f)))
            {
                EditorGUIUtility.systemCopyBuffer = AuditReportExporter.BuildClipboardSummary(LastResult, lang);
                StatusBanner = AvatarAuditLocalization.Get("ui.copied_clipboard", lang);
            }

            DrawExtraToolbarButtons(lang);
            GUI.enabled = true;
            EditorGUILayout.EndHorizontal();

            bool sdkPresent = VRCSDKReflectionBridge.IsVRCSDKPresent();
            EditorGUILayout.LabelField(
                AvatarAuditLocalization.Get(sdkPresent ? "ui.vrcsdk_detected" : "ui.vrcsdk_not_detected", lang),
                EditorStyles.miniLabel);

            EditorGUILayout.EndVertical();
        }

        protected virtual void DrawExtraToolbarButtons(AuditLanguage lang)
        {
        }

        protected void RunAuditNow()
        {
            if (TargetAvatar == null) return;
            StatusBanner = string.Empty;
            LastResult = AvatarAuditCore.RunAudit(TargetAvatar, SelectedPlatform, AvatarAuditLocalization.CurrentLanguage);
            OnAuditCompleted();
            Repaint();
        }

        protected virtual void OnAuditCompleted()
        {
        }

        private void RefreshRecommendationsLanguage()
        {
            if (LastResult != null && TargetAvatar != null)
            {
                RunAuditNow();
            }
        }

        protected void DrawSummaryCards(AuditLanguage lang)
        {
            EditorGUILayout.BeginHorizontal();

            DrawKpiBox(
                AvatarAuditLocalization.Get("ui.overall_rank", lang),
                AvatarAuditLocalization.GetRankLabel(LastResult.OverallRank, lang),
                GetRankColor(LastResult.OverallRank));

            DrawKpiBox(
                AvatarAuditLocalization.Get("ui.vram_total", lang),
                string.Format(CultureInfo.InvariantCulture, "{0:0.1} MB ({1})", LastResult.TotalTextureMemoryMB, LastResult.UniqueTextureCount),
                GUI.contentColor);

            DrawKpiBox(
                AvatarAuditLocalization.Get("ui.issues_found", lang),
                LastResult.Issues.Count.ToString(CultureInfo.InvariantCulture),
                LastResult.Issues.Count > 0 ? new Color(0.85f, 0.35f, 0.2f) : new Color(0.25f, 0.65f, 0.38f));

            EditorGUILayout.EndHorizontal();
        }

        protected void DrawKpiBox(string label, string value, Color accent)
        {
            EditorGUILayout.BeginVertical(EditorStyles.helpBox);
            EditorGUILayout.LabelField(label, EditorStyles.miniLabel);
            var prev = GUI.contentColor;
            GUI.contentColor = accent;
            EditorGUILayout.LabelField(value, EditorStyles.boldLabel);
            GUI.contentColor = prev;
            EditorGUILayout.EndVertical();
        }

        protected void DrawRankTab(AuditLanguage lang)
        {
            if (LastResult.Recommendations.Count > 0)
            {
                EditorGUILayout.LabelField(AvatarAuditLocalization.Get("ui.recommendations", lang), EditorStyles.boldLabel);
                for (int i = 0; i < LastResult.Recommendations.Count; i++)
                {
                    var rec = LastResult.Recommendations[i];
                    EditorGUILayout.HelpBox(
                        string.Format("[P{0}] {1}\n{2}\n-> {3}", rec.Priority, rec.Title, rec.Detail, rec.EstimatedImpact),
                        rec.Priority == 1 ? MessageType.Error : MessageType.Warning);
                }
                EditorGUILayout.Space(6f);
            }

            EditorGUILayout.BeginHorizontal(EditorStyles.toolbar);
            GUILayout.Label(AvatarAuditLocalization.Get("ui.col.metric", lang), EditorStyles.boldLabel, GUILayout.Width(210f));
            GUILayout.Label(AvatarAuditLocalization.Get("ui.col.value", lang), EditorStyles.boldLabel, GUILayout.Width(95f));
            GUILayout.Label(AvatarAuditLocalization.Get("ui.col.rank", lang), EditorStyles.boldLabel, GUILayout.Width(90f));
            GUILayout.Label(AvatarAuditLocalization.Get("ui.col.limits", lang), EditorStyles.boldLabel);
            EditorGUILayout.EndHorizontal();

            for (int i = 0; i < LastResult.Metrics.Count; i++)
            {
                var m = LastResult.Metrics[i];
                EditorGUILayout.BeginHorizontal(EditorStyles.helpBox);
                GUILayout.Label(AvatarAuditLocalization.GetMetricName(m.Id, lang), GUILayout.Width(210f));
                GUILayout.Label(RankThresholds.FormatMetricValue(m), GUILayout.Width(95f));

                var prev = GUI.contentColor;
                if (m.RemovedOnPlatform)
                {
                    GUI.contentColor = Color.gray;
                    GUILayout.Label(AvatarAuditLocalization.Get("ui.removed_on_mobile", lang), GUILayout.Width(90f));
                }
                else
                {
                    GUI.contentColor = GetRankColor(m.Rank);
                    GUILayout.Label(AvatarAuditLocalization.GetRankLabel(m.Rank, lang), EditorStyles.boldLabel, GUILayout.Width(90f));
                }
                GUI.contentColor = prev;

                string limitsText = m.RemovedOnPlatform
                    ? "-"
                    : string.Format(CultureInfo.InvariantCulture, "{0} / {1} / {2} / {3}", m.Threshold.Excellent, m.Threshold.Good, m.Threshold.Medium, m.Threshold.Poor);
                if (m.HardCapExceeded)
                {
                    limitsText += "  [" + AvatarAuditLocalization.Get("ui.hardcap_exceeded", lang) + "]";
                }
                GUILayout.Label(limitsText, EditorStyles.miniLabel);
                EditorGUILayout.EndHorizontal();
            }
        }

        protected void DrawTexturesTab(AuditLanguage lang)
        {
            if (LastResult.Textures.Count == 0)
            {
                EditorGUILayout.HelpBox(AvatarAuditLocalization.Get("ui.no_textures", lang), MessageType.Info);
                return;
            }

            for (int i = 0; i < LastResult.Textures.Count; i++)
            {
                var tex = LastResult.Textures[i];
                EditorGUILayout.BeginHorizontal(EditorStyles.helpBox);
                EditorGUILayout.BeginVertical();
                EditorGUILayout.LabelField(
                    string.Format(CultureInfo.InvariantCulture, "#{0}  {1}  ({2:0.2} MB)", i + 1, tex.TextureName, tex.EstimatedMB),
                    EditorStyles.boldLabel);
                EditorGUILayout.LabelField(
                    string.Format(CultureInfo.InvariantCulture,
                        "{0}x{1} | {2} ({3:0.#} bpp) | Mips: {4} | MaxSize: {5} | Crunch: {6}",
                        tex.Width, tex.Height, tex.FormatName, tex.BitsPerPixel,
                        tex.MipMapsEnabled ? "On" : "Off", tex.MaxTextureSizeSetting,
                        tex.CrunchCompressed ? "On" : "Off"),
                    EditorStyles.miniLabel);
                EditorGUILayout.EndVertical();

                if (!string.IsNullOrEmpty(tex.AssetPath))
                {
                    if (GUILayout.Button(AvatarAuditLocalization.Get("ui.select_asset", lang), GUILayout.Width(64f), GUILayout.Height(30f)))
                    {
                        var asset = AssetDatabase.LoadAssetAtPath<Texture2D>(tex.AssetPath);
                        if (asset != null)
                        {
                            EditorGUIUtility.PingObject(asset);
                            Selection.activeObject = asset;
                        }
                    }
                }
                EditorGUILayout.EndHorizontal();
            }
        }

        protected void DrawIssuesTab(AuditLanguage lang)
        {
            if (LastResult.Issues.Count == 0)
            {
                EditorGUILayout.HelpBox(AvatarAuditLocalization.Get("ui.no_issues", lang), MessageType.Info);
                return;
            }

            for (int i = 0; i < LastResult.Issues.Count; i++)
            {
                var issue = LastResult.Issues[i];
                MessageType msgType = issue.Severity == DiagnosticSeverity.Error
                    ? MessageType.Error
                    : (issue.Severity == DiagnosticSeverity.Warning ? MessageType.Warning : MessageType.Info);

                EditorGUILayout.HelpBox(
                    string.Format("[{0}] {1}\n{2}\nObject: {3}\nFix: {4}",
                        issue.Category, issue.Title, issue.Detail, issue.ObjectPath, issue.ActionHint),
                    msgType);
            }
        }

        protected virtual void DrawFooter(AuditLanguage lang)
        {
            if (!IsProEdition)
            {
                EditorGUILayout.Space(4f);
                EditorGUILayout.HelpBox(AvatarAuditLocalization.Get("ui.pro_upsell", lang), MessageType.None);
            }
        }

        protected static Color GetRankColor(PerformanceRank rank)
        {
            switch (rank)
            {
                case PerformanceRank.Excellent: return new Color(0.22f, 0.72f, 0.42f);
                case PerformanceRank.Good:      return new Color(0.45f, 0.76f, 0.25f);
                case PerformanceRank.Medium:    return new Color(0.88f, 0.68f, 0.14f);
                case PerformanceRank.Poor:      return new Color(0.90f, 0.42f, 0.18f);
                default:                        return new Color(0.86f, 0.22f, 0.22f);
            }
        }
    }
}