using System;
using System.Collections.Generic;
using System.Globalization;

namespace KitWorks.AvatarAudit
{
    /// <summary>
    /// Official VRChat Avatar Performance Ranking System thresholds for PC and Mobile (Android / Quest / iOS).
    /// Source verified against creators.vrchat.com/avatars/avatar-performance-ranking-system/.
    /// </summary>
    public static class RankThresholds
    {
        private static readonly Dictionary<MetricId, MetricThreshold> PcThresholds = BuildPcThresholds();
        private static readonly Dictionary<MetricId, MetricThreshold> MobileThresholds = BuildMobileThresholds();

        public static IReadOnlyList<MetricId> OrderedMetricIds { get; } = new[]
        {
            MetricId.Triangles,
            MetricId.TextureMemoryMB,
            MetricId.SkinnedMeshes,
            MetricId.BasicMeshes,
            MetricId.MaterialSlots,
            MetricId.Bones,
            MetricId.PhysBoneComponents,
            MetricId.PhysBoneAffectedTransforms,
            MetricId.PhysBoneColliders,
            MetricId.PhysBoneCollisionChecks,
            MetricId.Contacts,
            MetricId.ConstraintCount,
            MetricId.ConstraintDepth,
            MetricId.Animators,
            MetricId.Lights,
            MetricId.AudioSources,
            MetricId.ParticleSystems,
            MetricId.TotalParticlesActive,
            MetricId.TrailRenderers,
            MetricId.LineRenderers,
            MetricId.Cloths,
            MetricId.TotalClothVertices,
            MetricId.PhysicsColliders,
            MetricId.PhysicsRigidbodies,
            MetricId.BoundsSize
        };

        private static Dictionary<MetricId, MetricThreshold> BuildPcThresholds()
        {
            return new Dictionary<MetricId, MetricThreshold>
            {
                { MetricId.Triangles,                  new MetricThreshold(MetricId.Triangles,                  32000, 70000, 70000, 70000, true,  MetricBlockingEffect.Fallback) },
                { MetricId.TextureMemoryMB,            new MetricThreshold(MetricId.TextureMemoryMB,            40.0,  75.0,  110.0, 150.0, false, MetricBlockingEffect.Fallback, "MB") },
                { MetricId.SkinnedMeshes,              new MetricThreshold(MetricId.SkinnedMeshes,              1,     2,     8,     16,    true,  MetricBlockingEffect.Fallback) },
                { MetricId.BasicMeshes,                new MetricThreshold(MetricId.BasicMeshes,                4,     8,     16,    24,    true,  MetricBlockingEffect.Fallback) },
                { MetricId.MaterialSlots,              new MetricThreshold(MetricId.MaterialSlots,              4,     8,     16,    32,    true,  MetricBlockingEffect.Fallback) },
                { MetricId.Bones,                      new MetricThreshold(MetricId.Bones,                      75,    150,   256,   400,   true,  MetricBlockingEffect.Fallback) },
                { MetricId.PhysBoneComponents,         new MetricThreshold(MetricId.PhysBoneComponents,         4,     8,     16,    32,    true,  MetricBlockingEffect.StripPhysBonesAndContacts) },
                { MetricId.PhysBoneAffectedTransforms, new MetricThreshold(MetricId.PhysBoneAffectedTransforms, 16,    64,    128,   256,   true,  MetricBlockingEffect.StripPhysBonesAndContacts) },
                { MetricId.PhysBoneColliders,          new MetricThreshold(MetricId.PhysBoneColliders,          4,     8,     16,    32,    true,  MetricBlockingEffect.StripPhysBonesAndContacts) },
                { MetricId.PhysBoneCollisionChecks,    new MetricThreshold(MetricId.PhysBoneCollisionChecks,    32,    128,   256,   512,   true,  MetricBlockingEffect.StripPhysBonesAndContacts) },
                { MetricId.Contacts,                   new MetricThreshold(MetricId.Contacts,                   8,     16,    24,    32,    true,  MetricBlockingEffect.StripPhysBonesAndContacts) },
                { MetricId.ConstraintCount,            new MetricThreshold(MetricId.ConstraintCount,            100,   250,   300,   350,   true,  MetricBlockingEffect.StripConstraints) },
                { MetricId.ConstraintDepth,            new MetricThreshold(MetricId.ConstraintDepth,            20,    50,    80,    100,   true,  MetricBlockingEffect.StripConstraints) },
                { MetricId.Animators,                  new MetricThreshold(MetricId.Animators,                  1,     4,     16,    32,    true,  MetricBlockingEffect.Fallback) },
                { MetricId.Lights,                     new MetricThreshold(MetricId.Lights,                     0,     0,     0,     1,     true,  MetricBlockingEffect.StripLights) },
                { MetricId.AudioSources,               new MetricThreshold(MetricId.AudioSources,               1,     4,     8,     8,     true,  MetricBlockingEffect.StripAudio) },
                { MetricId.ParticleSystems,            new MetricThreshold(MetricId.ParticleSystems,            0,     4,     8,     16,    true,  MetricBlockingEffect.StripParticles) },
                { MetricId.TotalParticlesActive,       new MetricThreshold(MetricId.TotalParticlesActive,       0,     300,   1000,  2500,  true,  MetricBlockingEffect.StripParticles) },
                { MetricId.TrailRenderers,             new MetricThreshold(MetricId.TrailRenderers,             1,     2,     4,     8,     true,  MetricBlockingEffect.StripParticles) },
                { MetricId.LineRenderers,              new MetricThreshold(MetricId.LineRenderers,              1,     2,     4,     8,     true,  MetricBlockingEffect.StripParticles) },
                { MetricId.Cloths,                     new MetricThreshold(MetricId.Cloths,                     0,     1,     1,     1,     true,  MetricBlockingEffect.StripCloth) },
                { MetricId.TotalClothVertices,         new MetricThreshold(MetricId.TotalClothVertices,         0,     50,    100,   200,   true,  MetricBlockingEffect.StripCloth) },
                { MetricId.PhysicsColliders,           new MetricThreshold(MetricId.PhysicsColliders,           0,     1,     8,     8,     true,  MetricBlockingEffect.StripPhysics) },
                { MetricId.PhysicsRigidbodies,         new MetricThreshold(MetricId.PhysicsRigidbodies,         0,     1,     8,     8,     true,  MetricBlockingEffect.StripPhysics) },
                { MetricId.BoundsSize,                 new MetricThreshold(MetricId.BoundsSize,                 2.5,   4.0,   5.0,   5.0,   false, MetricBlockingEffect.Fallback, "m") }
            };
        }

        private static Dictionary<MetricId, MetricThreshold> BuildMobileThresholds()
        {
            return new Dictionary<MetricId, MetricThreshold>
            {
                { MetricId.Triangles,                  new MetricThreshold(MetricId.Triangles,                  7500,  10000, 15000, 20000, true,  MetricBlockingEffect.Fallback) },
                { MetricId.TextureMemoryMB,            new MetricThreshold(MetricId.TextureMemoryMB,            10.0,  18.0,  25.0,  40.0,  false, MetricBlockingEffect.Fallback, "MB") },
                { MetricId.SkinnedMeshes,              new MetricThreshold(MetricId.SkinnedMeshes,              1,     1,     2,     2,     true,  MetricBlockingEffect.Fallback) },
                { MetricId.BasicMeshes,                new MetricThreshold(MetricId.BasicMeshes,                1,     1,     2,     2,     true,  MetricBlockingEffect.Fallback) },
                { MetricId.MaterialSlots,              new MetricThreshold(MetricId.MaterialSlots,              1,     1,     2,     4,     true,  MetricBlockingEffect.Fallback) },
                { MetricId.Bones,                      new MetricThreshold(MetricId.Bones,                      75,    90,    150,   150,   true,  MetricBlockingEffect.Fallback) },
                { MetricId.PhysBoneComponents,         new MetricThreshold(MetricId.PhysBoneComponents,         0,     4,     6,     8,     true,  MetricBlockingEffect.StripPhysBonesAndContacts, "", true,  false) },
                { MetricId.PhysBoneAffectedTransforms, new MetricThreshold(MetricId.PhysBoneAffectedTransforms, 0,     16,    32,    64,    true,  MetricBlockingEffect.StripPhysBonesAndContacts, "", true,  false) },
                { MetricId.PhysBoneColliders,          new MetricThreshold(MetricId.PhysBoneColliders,          0,     4,     8,     16,    true,  MetricBlockingEffect.StripPhysBonesAndContacts, "", true,  false) },
                { MetricId.PhysBoneCollisionChecks,    new MetricThreshold(MetricId.PhysBoneCollisionChecks,    0,     16,    32,    64,    true,  MetricBlockingEffect.StripPhysBonesAndContacts, "", true,  false) },
                { MetricId.Contacts,                   new MetricThreshold(MetricId.Contacts,                   2,     4,     8,     16,    true,  MetricBlockingEffect.StripPhysBonesAndContacts, "", true,  false) },
                { MetricId.ConstraintCount,            new MetricThreshold(MetricId.ConstraintCount,            30,    60,    120,   150,   true,  MetricBlockingEffect.StripConstraints, "", true, false) },
                { MetricId.ConstraintDepth,            new MetricThreshold(MetricId.ConstraintDepth,            5,     15,    35,    50,    true,  MetricBlockingEffect.StripConstraints, "", true, false) },
                { MetricId.Animators,                  new MetricThreshold(MetricId.Animators,                  1,     1,     1,     2,     true,  MetricBlockingEffect.Fallback) },
                { MetricId.Lights,                     new MetricThreshold(MetricId.Lights,                     0,     0,     0,     0,     true,  MetricBlockingEffect.StripLights, "", false, true) },
                { MetricId.AudioSources,               new MetricThreshold(MetricId.AudioSources,               0,     0,     0,     0,     true,  MetricBlockingEffect.StripAudio, "", false, true) },
                { MetricId.ParticleSystems,            new MetricThreshold(MetricId.ParticleSystems,            0,     0,     0,     2,     true,  MetricBlockingEffect.StripParticles) },
                { MetricId.TotalParticlesActive,       new MetricThreshold(MetricId.TotalParticlesActive,       0,     0,     0,     200,   true,  MetricBlockingEffect.StripParticles) },
                { MetricId.TrailRenderers,             new MetricThreshold(MetricId.TrailRenderers,             0,     0,     0,     1,     true,  MetricBlockingEffect.StripParticles) },
                { MetricId.LineRenderers,              new MetricThreshold(MetricId.LineRenderers,              0,     0,     0,     1,     true,  MetricBlockingEffect.StripParticles) },
                { MetricId.Cloths,                     new MetricThreshold(MetricId.Cloths,                     0,     0,     0,     0,     true,  MetricBlockingEffect.StripCloth, "", false, true) },
                { MetricId.TotalClothVertices,         new MetricThreshold(MetricId.TotalClothVertices,         0,     0,     0,     0,     true,  MetricBlockingEffect.StripCloth, "", false, true) },
                { MetricId.PhysicsColliders,           new MetricThreshold(MetricId.PhysicsColliders,           0,     0,     0,     0,     true,  MetricBlockingEffect.StripPhysics, "", false, true) },
                { MetricId.PhysicsRigidbodies,         new MetricThreshold(MetricId.PhysicsRigidbodies,         0,     0,     0,     0,     true,  MetricBlockingEffect.StripPhysics, "", false, true) },
                { MetricId.BoundsSize,                 new MetricThreshold(MetricId.BoundsSize,                 2.5,   4.0,   5.0,   5.0,   false, MetricBlockingEffect.Fallback, "m") }
            };
        }

        public static MetricThreshold GetThreshold(TargetPlatform platform, MetricId metricId)
        {
            var table = platform == TargetPlatform.PC ? PcThresholds : MobileThresholds;
            return table[metricId];
        }

        public static PerformanceRank EvaluateRank(double value, MetricThreshold threshold)
        {
            if (threshold == null) throw new ArgumentNullException(nameof(threshold));
            const double eps = 1e-6;
            if (value <= threshold.Excellent + eps) return PerformanceRank.Excellent;
            if (value <= threshold.Good + eps) return PerformanceRank.Good;
            if (value <= threshold.Medium + eps) return PerformanceRank.Medium;
            if (value <= threshold.Poor + eps) return PerformanceRank.Poor;
            return PerformanceRank.VeryPoor;
        }

        public static PerformanceRank EvaluateBoundsRank(float sizeX, float sizeY, float sizeZ)
        {
            const float eps = 1e-4f;
            if (sizeX <= 2.5f + eps && sizeY <= 2.5f + eps && sizeZ <= 2.5f + eps) return PerformanceRank.Excellent;
            if (sizeX <= 4.0f + eps && sizeY <= 4.0f + eps && sizeZ <= 4.0f + eps) return PerformanceRank.Good;
            if (sizeX <= 5.0f + eps && sizeY <= 6.0f + eps && sizeZ <= 5.0f + eps) return PerformanceRank.Medium;
            return PerformanceRank.VeryPoor;
        }

        public static MetricEvaluation EvaluateMetric(TargetPlatform platform, MetricId metricId, double value, bool forceVeryPoor = false, string forcedReason = null)
        {
            var threshold = GetThreshold(platform, metricId);
            var eval = new MetricEvaluation
            {
                Id = metricId,
                CurrentValue = value,
                IsInteger = threshold.IsInteger,
                Threshold = threshold,
                RemovedOnPlatform = platform == TargetPlatform.Mobile && threshold.IsRemovedOnMobile
            };

            if (eval.RemovedOnPlatform)
            {
                eval.Rank = PerformanceRank.Excellent;
                eval.HardCapExceeded = false;
                eval.ExcessOverPoor = 0;
                eval.ExcessOverNextBetterRank = 0;
                eval.HeadroomToNextWorseRank = 0;
                return eval;
            }

            if (forceVeryPoor)
            {
                eval.Rank = PerformanceRank.VeryPoor;
                eval.ForcedReason = forcedReason;
            }
            else
            {
                eval.Rank = EvaluateRank(value, threshold);
            }

            eval.HardCapExceeded = platform == TargetPlatform.Mobile && threshold.IsHardCapOnMobile && value > threshold.Poor + 1e-6;
            eval.ExcessOverPoor = Math.Max(0.0, value - threshold.Poor);

            if (eval.Rank == PerformanceRank.Excellent)
            {
                eval.ExcessOverNextBetterRank = 0.0;
                eval.HeadroomToNextWorseRank = Math.Max(0.0, threshold.Excellent - value);
            }
            else
            {
                PerformanceRank betterRank = (PerformanceRank)((int)eval.Rank - 1);
                double betterLimit = threshold.GetLimitForRank(betterRank);
                while (betterRank > PerformanceRank.Excellent && Math.Abs(betterLimit - threshold.GetLimitForRank(eval.Rank)) < 1e-6 && eval.Rank != PerformanceRank.VeryPoor)
                {
                    betterRank = (PerformanceRank)((int)betterRank - 1);
                    betterLimit = threshold.GetLimitForRank(betterRank);
                }
                eval.ExcessOverNextBetterRank = Math.Max(0.0, value - betterLimit);
                eval.HeadroomToNextWorseRank = eval.Rank == PerformanceRank.VeryPoor
                    ? 0.0
                    : Math.Max(0.0, threshold.GetLimitForRank(eval.Rank) - value);
            }

            return eval;
        }

        public static MetricEvaluation EvaluateBounds(TargetPlatform platform, BoundsAuditInfo bounds)
        {
            var threshold = GetThreshold(platform, MetricId.BoundsSize);
            double maxAxis = bounds != null ? bounds.MaxAxis : 0.0;
            PerformanceRank rank = bounds != null
                ? EvaluateBoundsRank(bounds.SizeX, bounds.SizeY, bounds.SizeZ)
                : PerformanceRank.Excellent;

            return new MetricEvaluation
            {
                Id = MetricId.BoundsSize,
                CurrentValue = maxAxis,
                IsInteger = false,
                Threshold = threshold,
                Rank = rank,
                ExcessOverPoor = rank == PerformanceRank.VeryPoor ? Math.Max(0.0, maxAxis - 5.0) : 0.0,
                ExcessOverNextBetterRank = 0.0,
                HeadroomToNextWorseRank = 0.0,
                ExtraDisplayValue = bounds != null
                    ? string.Format(CultureInfo.InvariantCulture, "{0:0.00} x {1:0.00} x {2:0.00} m", bounds.SizeX, bounds.SizeY, bounds.SizeZ)
                    : "0.00 x 0.00 x 0.00 m"
            };
        }

        public static PerformanceRank ComputeOverallRank(IEnumerable<MetricEvaluation> evaluations, bool hasMeshReadWriteDisabled)
        {
            if (hasMeshReadWriteDisabled) return PerformanceRank.VeryPoor;

            PerformanceRank worst = PerformanceRank.Excellent;
            if (evaluations != null)
            {
                foreach (var eval in evaluations)
                {
                    if (eval == null || eval.RemovedOnPlatform) continue;
                    if ((int)eval.Rank > (int)worst)
                    {
                        worst = eval.Rank;
                    }
                }
            }
            return worst;
        }

        public static List<OptimizationRecommendation> BuildRecommendations(AvatarAuditResult result, AuditLanguage lang)
        {
            var recs = new List<OptimizationRecommendation>();
            if (result == null) return recs;

            if (result.HasMeshReadWriteDisabled)
            {
                recs.Add(new OptimizationRecommendation
                {
                    Priority = 1,
                    MetricId = MetricId.Triangles,
                    Title = AvatarAuditLocalization.Get("rec.mesh_rw.title", lang),
                    Detail = AvatarAuditLocalization.Get("rec.mesh_rw.detail", lang),
                    EstimatedImpact = AvatarAuditLocalization.Get("rec.mesh_rw.impact", lang)
                });
            }

            foreach (var eval in result.Metrics)
            {
                if (eval.RemovedOnPlatform) continue;
                if (eval.Rank < PerformanceRank.Poor && !eval.HardCapExceeded) continue;

                int priority = eval.HardCapExceeded || eval.Rank == PerformanceRank.VeryPoor ? 1 : 2;
                string metricName = AvatarAuditLocalization.GetMetricName(eval.Id, lang);
                string currentFmt = FormatMetricValue(eval);
                string limitFmt = eval.IsInteger
                    ? string.Format(CultureInfo.InvariantCulture, "{0:N0}", eval.Threshold.Poor)
                    : string.Format(CultureInfo.InvariantCulture, "{0:0.#}{1}", eval.Threshold.Poor, string.IsNullOrEmpty(eval.Threshold.Unit) ? "" : " " + eval.Threshold.Unit);

                string detail;
                if (eval.HardCapExceeded)
                {
                    detail = string.Format(
                        AvatarAuditLocalization.Get("rec.hardcap.detail", lang),
                        metricName, currentFmt, limitFmt);
                }
                else if (eval.Rank == PerformanceRank.VeryPoor)
                {
                    string excessFmt = eval.IsInteger
                        ? string.Format(CultureInfo.InvariantCulture, "{0:N0}", Math.Ceiling(eval.ExcessOverPoor))
                        : string.Format(CultureInfo.InvariantCulture, "{0:0.1} {1}", eval.ExcessOverPoor, eval.Threshold.Unit);
                    detail = string.Format(
                        AvatarAuditLocalization.Get("rec.verypoor.detail", lang),
                        metricName, currentFmt, limitFmt, excessFmt);
                }
                else
                {
                    string medLimit = eval.IsInteger
                        ? string.Format(CultureInfo.InvariantCulture, "{0:N0}", eval.Threshold.Medium)
                        : string.Format(CultureInfo.InvariantCulture, "{0:0.#} {1}", eval.Threshold.Medium, eval.Threshold.Unit);
                    detail = string.Format(
                        AvatarAuditLocalization.Get("rec.poor.detail", lang),
                        metricName, currentFmt, medLimit);
                }

                recs.Add(new OptimizationRecommendation
                {
                    Priority = priority,
                    MetricId = eval.Id,
                    Title = string.Format(AvatarAuditLocalization.Get("rec.metric.title", lang), metricName, AvatarAuditLocalization.GetRankLabel(eval.Rank, lang)),
                    Detail = detail,
                    EstimatedImpact = GetActionAdvice(eval.Id, result.Platform, lang)
                });
            }

            if (result.MissingScriptCount > 0)
            {
                recs.Add(new OptimizationRecommendation
                {
                    Priority = 1,
                    MetricId = MetricId.Animators,
                    Title = AvatarAuditLocalization.Get("rec.missing_scripts.title", lang),
                    Detail = string.Format(AvatarAuditLocalization.Get("rec.missing_scripts.detail", lang), result.MissingScriptCount),
                    EstimatedImpact = AvatarAuditLocalization.Get("rec.missing_scripts.impact", lang)
                });
            }

            if (result.DuplicateMaterials != null && result.DuplicateMaterials.Count > 0)
            {
                int saved = 0;
                foreach (var grp in result.DuplicateMaterials) saved += grp.PotentialMaterialsSaved;
                recs.Add(new OptimizationRecommendation
                {
                    Priority = 3,
                    MetricId = MetricId.MaterialSlots,
                    Title = AvatarAuditLocalization.Get("rec.dup_mat.title", lang),
                    Detail = string.Format(AvatarAuditLocalization.Get("rec.dup_mat.detail", lang), result.DuplicateMaterials.Count, saved),
                    EstimatedImpact = AvatarAuditLocalization.Get("rec.dup_mat.impact", lang)
                });
            }

            recs.Sort((a, b) => a.Priority.CompareTo(b.Priority));
            return recs;
        }

        public static string FormatMetricValue(MetricEvaluation eval)
        {
            if (eval == null) return "-";
            if (!string.IsNullOrEmpty(eval.ExtraDisplayValue)) return eval.ExtraDisplayValue;
            if (eval.IsInteger)
            {
                return string.Format(CultureInfo.InvariantCulture, "{0:N0}", Math.Round(eval.CurrentValue));
            }
            string unit = string.IsNullOrEmpty(eval.Threshold.Unit) ? "" : " " + eval.Threshold.Unit;
            return string.Format(CultureInfo.InvariantCulture, "{0:0.0}{1}", eval.CurrentValue, unit);
        }

        private static string GetActionAdvice(MetricId id, TargetPlatform platform, AuditLanguage lang)
        {
            switch (id)
            {
                case MetricId.TextureMemoryMB:
                    return platform == TargetPlatform.Mobile
                        ? AvatarAuditLocalization.Get("advice.vram.mobile", lang)
                        : AvatarAuditLocalization.Get("advice.vram.pc", lang);
                case MetricId.Triangles:
                    return AvatarAuditLocalization.Get("advice.triangles", lang);
                case MetricId.MaterialSlots:
                case MetricId.SkinnedMeshes:
                    return AvatarAuditLocalization.Get("advice.materials", lang);
                case MetricId.PhysBoneComponents:
                case MetricId.PhysBoneAffectedTransforms:
                case MetricId.PhysBoneColliders:
                case MetricId.PhysBoneCollisionChecks:
                    return AvatarAuditLocalization.Get("advice.physbones", lang);
                case MetricId.Bones:
                    return AvatarAuditLocalization.Get("advice.bones", lang);
                default:
                    return AvatarAuditLocalization.Get("advice.general", lang);
            }
        }
    }
}