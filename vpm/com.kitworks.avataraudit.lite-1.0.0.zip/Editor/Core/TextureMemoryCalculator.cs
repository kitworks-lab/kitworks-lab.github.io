using System;
using System.Collections.Generic;
using UnityEngine;

namespace KitWorks.AvatarAudit
{
    /// <summary>
    /// Accurate GPU texture VRAM estimator matching Unity / VRChat runtime memory layout.
    /// Accounts for compressed block formats (BC1/DXT1, BC3/DXT5, BC7, ASTC, ETC2, RGBA32/Half/Float)
    /// and mipmap chains (x 4/3 = 1.3333333).
    /// </summary>
    public static class TextureMemoryCalculator
    {
        public const double MipMapMultiplier = 4.0 / 3.0;
        public const double BytesPerMB = 1024.0 * 1024.0;

        public static double GetBitsPerPixel(TextureFormat format)
        {
            switch (format)
            {
                case TextureFormat.DXT1:
                case TextureFormat.DXT1Crunched:
                case TextureFormat.BC4:
                case TextureFormat.ETC_RGB4:
                case TextureFormat.ETC2_RGB:
                case TextureFormat.ETC_RGB4Crunched:
                case TextureFormat.PVRTC_RGB4:
                case TextureFormat.PVRTC_RGBA4:
                    return 4.0;

                case TextureFormat.PVRTC_RGB2:
                case TextureFormat.PVRTC_RGBA2:
                    return 2.0;

                case TextureFormat.DXT5:
                case TextureFormat.DXT5Crunched:
                case TextureFormat.BC5:
                case TextureFormat.BC6H:
                case TextureFormat.BC7:
                case TextureFormat.ETC2_RGBA8:
                case TextureFormat.ETC2_RGBA8Crunched:
                case TextureFormat.ASTC_4x4:
                case TextureFormat.Alpha8:
                case TextureFormat.R8:
                    return 8.0;

                case TextureFormat.ASTC_5x5:
                    return 128.0 / 25.0;
                case TextureFormat.ASTC_6x6:
                    return 128.0 / 36.0;
                case TextureFormat.ASTC_8x8:
                    return 128.0 / 64.0;
                case TextureFormat.ASTC_10x10:
                    return 128.0 / 100.0;
                case TextureFormat.ASTC_12x12:
                    return 128.0 / 144.0;

                case TextureFormat.RGB565:
                case TextureFormat.RGBA4444:
                case TextureFormat.R16:
                case TextureFormat.RG16:
                case TextureFormat.RHalf:
                    return 16.0;

                case TextureFormat.RGB24:
                    return 24.0;

                case TextureFormat.RGBA32:
                case TextureFormat.ARGB32:
                case TextureFormat.BGRA32:
                case TextureFormat.RGHalf:
                case TextureFormat.RFloat:
                    return 32.0;

                case TextureFormat.RGBAHalf:
                case TextureFormat.RGFloat:
                    return 64.0;

                case TextureFormat.RGBAFloat:
                    return 128.0;

                default:
                    return 32.0;
            }
        }

        public static double GetBitsPerPixelByName(string formatName)
        {
            if (string.IsNullOrEmpty(formatName)) return 8.0;
            TextureFormat parsed;
            if (Enum.TryParse(formatName, true, out parsed))
            {
                return GetBitsPerPixel(parsed);
            }

            string upper = formatName.ToUpperInvariant();
            if (upper.Contains("ASTC_6X6")) return 128.0 / 36.0;
            if (upper.Contains("ASTC_8X8")) return 2.0;
            if (upper.Contains("ASTC_4X4")) return 8.0;
            if (upper.Contains("DXT1") || upper.Contains("BC1") || upper.Contains("ETC2_RGB")) return 4.0;
            if (upper.Contains("DXT5") || upper.Contains("BC3") || upper.Contains("BC7") || upper.Contains("ETC2_RGBA")) return 8.0;
            if (upper.Contains("RGBA32") || upper.Contains("ARGB32")) return 32.0;
            if (upper.Contains("RGB24")) return 24.0;
            if (upper.Contains("RGBAHALF")) return 64.0;
            if (upper.Contains("RGBAFLOAT")) return 128.0;
            return 8.0;
        }

        public static long CalculateBytes(int width, int height, TextureFormat format, bool hasMipMaps)
        {
            return CalculateBytes(width, height, GetBitsPerPixel(format), hasMipMaps);
        }

        public static long CalculateBytes(int width, int height, double bitsPerPixel, bool hasMipMaps)
        {
            if (width <= 0 || height <= 0 || bitsPerPixel <= 0.0) return 0L;
            double baseBytes = (double)width * (double)height * bitsPerPixel / 8.0;
            double totalBytes = hasMipMaps ? baseBytes * MipMapMultiplier : baseBytes;
            return (long)Math.Ceiling(totalBytes);
        }

        public static double BytesToMB(long bytes)
        {
            return bytes / BytesPerMB;
        }

        public static void ComputeScaledDimensions(int width, int height, int maxTextureSize, out int outWidth, out int outHeight)
        {
            if (width <= 0 || height <= 0 || maxTextureSize <= 0)
            {
                outWidth = Math.Max(0, width);
                outHeight = Math.Max(0, height);
                return;
            }

            int longest = Math.Max(width, height);
            if (longest <= maxTextureSize)
            {
                outWidth = width;
                outHeight = height;
                return;
            }

            double scale = (double)maxTextureSize / (double)longest;
            outWidth = Math.Max(4, (int)Math.Round(width * scale));
            outHeight = Math.Max(4, (int)Math.Round(height * scale));
        }

        public static TextureOptimizationPlan BuildOptimizationPlan(IEnumerable<TextureAuditItem> textures, OptimizationPreset preset)
        {
            var plan = new TextureOptimizationPlan { Preset = preset };
            if (textures == null) return plan;

            int targetMaxSize;
            bool enableCrunch;
            int crunchQuality;
            bool applyAndroidAstc;

            switch (preset)
            {
                case OptimizationPreset.PCBalanced2KCrunch:
                    targetMaxSize = 2048;
                    enableCrunch = true;
                    crunchQuality = 75;
                    applyAndroidAstc = false;
                    break;
                case OptimizationPreset.PCLightweight1KCrunch:
                    targetMaxSize = 1024;
                    enableCrunch = true;
                    crunchQuality = 65;
                    applyAndroidAstc = false;
                    break;
                case OptimizationPreset.QuestSafe1KASTC6x6:
                    targetMaxSize = 1024;
                    enableCrunch = false;
                    crunchQuality = 50;
                    applyAndroidAstc = true;
                    break;
                default:
                    targetMaxSize = 2048;
                    enableCrunch = true;
                    crunchQuality = 75;
                    applyAndroidAstc = false;
                    break;
            }

            foreach (var tex in textures)
            {
                if (tex == null) continue;

                int newW, newH;
                ComputeScaledDimensions(tex.Width, tex.Height, targetMaxSize, out newW, out newH);

                double targetBpp;
                string targetFormat;
                if (applyAndroidAstc)
                {
                    targetFormat = "ASTC_6x6";
                    targetBpp = GetBitsPerPixel(TextureFormat.ASTC_6x6);
                }
                else
                {
                    if (tex.BitsPerPixel <= 4.1)
                    {
                        targetFormat = enableCrunch && !tex.IsNormalMap ? "DXT1Crunched" : "DXT1";
                        targetBpp = 4.0;
                    }
                    else
                    {
                        targetFormat = enableCrunch && !tex.IsNormalMap ? "DXT5Crunched" : "DXT5";
                        targetBpp = 8.0;
                    }
                }

                long currentBytes = tex.EstimatedBytes > 0
                    ? tex.EstimatedBytes
                    : CalculateBytes(tex.Width, tex.Height, tex.BitsPerPixel, tex.MipMapsEnabled);
                long newBytes = CalculateBytes(newW, newH, targetBpp, tex.MipMapsEnabled);

                bool sizeChanges = (tex.MaxTextureSizeSetting > targetMaxSize) || (newW < tex.Width) || (newH < tex.Height);
                bool formatChanges = applyAndroidAstc
                    ? !string.Equals(tex.FormatName, "ASTC_6x6", StringComparison.OrdinalIgnoreCase)
                    : (tex.BitsPerPixel > 8.1) || (enableCrunch && !tex.CrunchCompressed && !tex.IsNormalMap);

                bool willChange = sizeChanges || formatChanges;
                if (!willChange)
                {
                    newBytes = currentBytes;
                }

                long saved = Math.Max(0L, currentBytes - newBytes);

                var item = new TextureOptimizationPlanItem
                {
                    AssetPath = tex.AssetPath,
                    TextureName = tex.TextureName,
                    CurrentWidth = tex.Width,
                    CurrentHeight = tex.Height,
                    TargetWidth = newW,
                    TargetHeight = newH,
                    CurrentFormat = tex.FormatName,
                    TargetFormat = willChange ? targetFormat : tex.FormatName,
                    CurrentMipMaps = tex.MipMapsEnabled,
                    TargetMipMaps = tex.MipMapsEnabled,
                    CurrentBytes = currentBytes,
                    EstimatedNewBytes = newBytes,
                    SavedBytes = saved,
                    WillChange = willChange,
                    SkipReason = willChange ? string.Empty : "Already meets preset",
                    TargetMaxSize = targetMaxSize,
                    EnableCrunch = enableCrunch && !tex.IsNormalMap,
                    CrunchQuality = crunchQuality,
                    ApplyAndroidASTC = applyAndroidAstc
                };

                plan.Items.Add(item);
                plan.TotalCurrentBytes += currentBytes;
                plan.TotalEstimatedNewBytes += newBytes;
                if (willChange) plan.AffectedTextureCount++;
            }

            plan.TotalSavedBytes = Math.Max(0L, plan.TotalCurrentBytes - plan.TotalEstimatedNewBytes);
            plan.TotalCurrentMB = BytesToMB(plan.TotalCurrentBytes);
            plan.TotalEstimatedNewMB = BytesToMB(plan.TotalEstimatedNewBytes);
            plan.TotalSavedMB = BytesToMB(plan.TotalSavedBytes);
            return plan;
        }
    }
}