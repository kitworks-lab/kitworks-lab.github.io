using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using UnityEngine;

namespace KitWorks.AvatarAudit
{
    public sealed class VRCSDKScanData
    {
        public bool HasVRCSDK;
        public bool HasAvatarDescriptor;
        public int PhysBoneComponents;
        public int PhysBoneAffectedTransforms;
        public int PhysBoneColliders;
        public int PhysBoneCollisionChecks;
        public int Contacts;
        public int VRCConstraintCount;
    }

    /// <summary>
    /// Zero-dependency reflection bridge for VRCSDK3 Avatars components.
    /// Compiles cleanly with or without VRCSDK installed in the Unity project.
    /// </summary>
    public static class VRCSDKReflectionBridge
    {
        private static bool _initialized;
        private static Type _avatarDescriptorType;
        private static Type _physBoneType;
        private static Type _physBoneColliderType;
        private static Type _contactSenderType;
        private static Type _contactReceiverType;
        private static Type _vrcConstraintBaseType;

        public static void ResetCache()
        {
            _initialized = false;
            _avatarDescriptorType = null;
            _physBoneType = null;
            _physBoneColliderType = null;
            _contactSenderType = null;
            _contactReceiverType = null;
            _vrcConstraintBaseType = null;
        }

        private static void EnsureInitialized()
        {
            if (_initialized) return;
            _initialized = true;

            _avatarDescriptorType = FindTypeByFullNameOrShortName("VRC.SDK3.Avatars.Components.VRCAvatarDescriptor", "VRCAvatarDescriptor");
            _physBoneType = FindTypeByFullNameOrShortName("VRC.SDK3.Dynamics.PhysBone.Components.VRCPhysBone", "VRCPhysBone");
            _physBoneColliderType = FindTypeByFullNameOrShortName("VRC.SDK3.Dynamics.PhysBone.Components.VRCPhysBoneCollider", "VRCPhysBoneCollider");
            _contactSenderType = FindTypeByFullNameOrShortName("VRC.SDK3.Dynamics.Contact.Components.VRCContactSender", "VRCContactSender");
            _contactReceiverType = FindTypeByFullNameOrShortName("VRC.SDK3.Dynamics.Contact.Components.VRCContactReceiver", "VRCContactReceiver");
            _vrcConstraintBaseType = FindTypeByFullNameOrShortName("VRC.Dynamics.VRCConstraintBase", "VRCConstraintBase");
        }

        public static bool IsVRCSDKPresent()
        {
            EnsureInitialized();
            return _avatarDescriptorType != null || _physBoneType != null;
        }

        public static VRCSDKScanData Scan(GameObject avatarRoot)
        {
            EnsureInitialized();
            var data = new VRCSDKScanData
            {
                HasVRCSDK = IsVRCSDKPresent()
            };

            if (avatarRoot == null || !data.HasVRCSDK)
            {
                return data;
            }

            if (_avatarDescriptorType != null)
            {
                data.HasAvatarDescriptor = avatarRoot.GetComponentInChildren(_avatarDescriptorType, true) != null;
            }

            if (_physBoneColliderType != null)
            {
                Component[] colliders = avatarRoot.GetComponentsInChildren(_physBoneColliderType, true);
                data.PhysBoneColliders = colliders != null ? colliders.Length : 0;
            }

            if (_physBoneType != null)
            {
                Component[] physBones = avatarRoot.GetComponentsInChildren(_physBoneType, true);
                if (physBones != null)
                {
                    data.PhysBoneComponents = physBones.Length;
                    var otherRoots = new HashSet<Transform>();
                    for (int i = 0; i < physBones.Length; i++)
                    {
                        Transform rt = GetPhysBoneRootTransform(physBones[i]);
                        if (rt != null) otherRoots.Add(rt);
                    }

                    for (int i = 0; i < physBones.Length; i++)
                    {
                        Component pb = physBones[i];
                        if (pb == null) continue;

                        int affected = CountAffectedTransforms(pb, otherRoots);
                        data.PhysBoneAffectedTransforms += affected;

                        int colliderSlots = CountNonNullColliders(pb);
                        if (colliderSlots > 0 && affected > 0)
                        {
                            data.PhysBoneCollisionChecks += affected * colliderSlots;
                        }
                    }
                }
            }

            if (_contactSenderType != null)
            {
                Component[] senders = avatarRoot.GetComponentsInChildren(_contactSenderType, true);
                if (senders != null) data.Contacts += senders.Length;
            }

            if (_contactReceiverType != null)
            {
                Component[] receivers = avatarRoot.GetComponentsInChildren(_contactReceiverType, true);
                if (receivers != null) data.Contacts += receivers.Length;
            }

            if (_vrcConstraintBaseType != null)
            {
                Component[] vrcConstraints = avatarRoot.GetComponentsInChildren(_vrcConstraintBaseType, true);
                if (vrcConstraints != null) data.VRCConstraintCount = vrcConstraints.Length;
            }

            return data;
        }

        private static Transform GetPhysBoneRootTransform(Component physBone)
        {
            if (physBone == null) return null;
            object rootObj = GetMemberValue(physBone, "rootTransform");
            Transform root = rootObj as Transform;
            return root != null ? root : physBone.transform;
        }

        private static int CountAffectedTransforms(Component physBone, HashSet<Transform> allPhysBoneRoots)
        {
            Transform root = GetPhysBoneRootTransform(physBone);
            if (root == null) return 0;

            var ignored = new HashSet<Transform>();
            object ignoreListObj = GetMemberValue(physBone, "ignoreTransforms");
            IEnumerable ignoreEnum = ignoreListObj as IEnumerable;
            if (ignoreEnum != null)
            {
                foreach (object item in ignoreEnum)
                {
                    Transform t = item as Transform;
                    if (t != null) ignored.Add(t);
                }
            }

            bool ignoreOther = false;
            object ignoreOtherObj = GetMemberValue(physBone, "ignoreOther");
            if (ignoreOtherObj is bool)
            {
                ignoreOther = (bool)ignoreOtherObj;
            }

            bool hasEndpoint = false;
            object endpointObj = GetMemberValue(physBone, "endpointPosition");
            if (endpointObj is Vector3)
            {
                Vector3 ep = (Vector3)endpointObj;
                hasEndpoint = ep.sqrMagnitude > 1e-6f;
            }

            int count = 0;
            TraversePhysBoneHierarchy(root, root, ignored, allPhysBoneRoots, ignoreOther, hasEndpoint, ref count);
            return count;
        }

        private static void TraversePhysBoneHierarchy(
            Transform current,
            Transform chainRoot,
            HashSet<Transform> ignored,
            HashSet<Transform> allPhysBoneRoots,
            bool ignoreOther,
            bool hasEndpoint,
            ref int count)
        {
            if (current == null) return;
            if (current != chainRoot && ignored.Contains(current)) return;
            if (current != chainRoot && ignoreOther && allPhysBoneRoots.Contains(current)) return;

            count++;

            int childCount = current.childCount;
            int validChildren = 0;
            for (int i = 0; i < childCount; i++)
            {
                Transform child = current.GetChild(i);
                if (child == null) continue;
                if (ignored.Contains(child)) continue;
                if (ignoreOther && allPhysBoneRoots.Contains(child)) continue;
                validChildren++;
                TraversePhysBoneHierarchy(child, chainRoot, ignored, allPhysBoneRoots, ignoreOther, hasEndpoint, ref count);
            }

            if (validChildren == 0 && hasEndpoint)
            {
                count++;
            }
        }

        private static int CountNonNullColliders(Component physBone)
        {
            object collidersObj = GetMemberValue(physBone, "colliders");
            IEnumerable colEnum = collidersObj as IEnumerable;
            if (colEnum == null) return 0;

            int count = 0;
            foreach (object item in colEnum)
            {
                if (item != null && !item.Equals(null))
                {
                    count++;
                }
            }
            return count;
        }

        private static object GetMemberValue(object instance, string memberName)
        {
            if (instance == null || string.IsNullOrEmpty(memberName)) return null;
            Type type = instance.GetType();
            const BindingFlags flags = BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic;

            FieldInfo field = type.GetField(memberName, flags);
            if (field != null)
            {
                return field.GetValue(instance);
            }

            PropertyInfo prop = type.GetProperty(memberName, flags);
            if (prop != null && prop.CanRead)
            {
                return prop.GetValue(instance, null);
            }

            return null;
        }

        private static Type FindTypeByFullNameOrShortName(string fullName, string shortName)
        {
            Assembly[] assemblies = AppDomain.CurrentDomain.GetAssemblies();
            Type shortFallback = null;

            for (int i = 0; i < assemblies.Length; i++)
            {
                Assembly asm = assemblies[i];
                if (asm == null) continue;

                Type exact = asm.GetType(fullName, false);
                if (exact != null) return exact;

                Type[] types;
                try
                {
                    types = asm.GetTypes();
                }
                catch (ReflectionTypeLoadException ex)
                {
                    types = ex.Types;
                }
                catch
                {
                    continue;
                }

                if (types == null) continue;
                for (int t = 0; t < types.Length; t++)
                {
                    Type candidate = types[t];
                    if (candidate == null) continue;
                    if (string.Equals(candidate.FullName, fullName, StringComparison.Ordinal))
                    {
                        return candidate;
                    }
                    if (shortFallback == null && string.Equals(candidate.Name, shortName, StringComparison.Ordinal))
                    {
                        shortFallback = candidate;
                    }
                }
            }

            return shortFallback;
        }
    }
}