AvatarAudit for Unity (VRChat Avatars 3.0)
Version 1.0.0 / KitWorks Lab
Requires: Unity 2022.3 LTS (2022.3.22f1 recommended). No hard dependency on VRCSDK.

============================================================
Overview
============================================================
AvatarAudit inspects VRChat Avatars 3.0 rigs inside the Unity Editor, showing exact PC and Android/Quest performance ranks, real GPU texture VRAM usage, and structural errors in one window.

VRChat SDK components (VRCAvatarDescriptor, VRCPhysBone, VRCPhysBoneCollider, VRCContactSender/Receiver, VRCConstraints) are inspected via safe reflection. The tool compiles and runs cleanly regardless of which VRCSDK version you use, or even in plain Unity projects without VRCSDK installed.

============================================================
Installation
============================================================
Option A: VRChat Creator Companion (VCC / VPM)
1. Add the KitWorks VPM repository URL in VCC (Settings > Packages > Add Repository), or extract the included VPM zip into your local VCC User Packages folder.
2. Add AvatarAudit to your avatar project from Manage Project.

Option B: Unity Package (.unitypackage)
1. Open your Unity 2022.3 project.
2. Drag and drop the .unitypackage file into the Project window and click Import.
Note: If upgrading from Lite to Pro via .unitypackage, you can delete Assets/KitWorks/AvatarAuditLite to keep the menu clean (keeping both will not cause compile errors).

============================================================
Quick Start
============================================================
1. Open the tool from the top Unity menu:
   - Lite: Tools > KitWorks > AvatarAudit Lite
   - Pro : Tools > KitWorks > AvatarAudit Pro
2. Drag your avatar root GameObject from the Hierarchy into Target Avatar.
3. Choose PC (Windows) or Android / Quest (Mobile) and click Run Audit.
4. Switch between Japanese (JP) and English (EN) at any time from the top-right toolbar.

============================================================
Features
============================================================
Included in Lite and Pro:
- Full PC and Mobile (Android/Quest/iOS) VRChat Performance Rank breakdown across 25 official metrics, including headroom and excess counts.
- Mesh Read/Write disabled detection (which forces Very Poor in VRChat) and Mobile hard-cap alerts (PhysBones, Contacts, and Constraints limits where VRChat strips components on Quest).
- Real GPU Texture VRAM ranking accounting for dimensions, mipmap chains (x 1.333), and compressed block formats (DXT1/BC1, DXT5/BC3, BC7, ASTC 4x4/6x6/8x8, ETC2, RGBA32). Click Ping to jump directly to any texture asset.
- Diagnostics for Missing Scripts, broken or null materials, 4K+ textures, unused BlendShape counts, duplicate material groups, and missing essential Humanoid bones.
- One-click Copy Summary to Clipboard.

Added in Pro:
- One-click Batch Texture/VRAM Optimizer with 3 presets:
  1. PC Balanced (2048px Max / Crunch 75%)
  2. PC Lightweight (1024px Max / Crunch 65%)
  3. Quest / Android Safe (1024px Max / ASTC 6x6)
  Preview exact MB savings before applying. Every run writes original TextureImporter settings (including Android/Standalone overrides) to Library/KitWorks_AvatarAudit_TextureBackup.json so you can restore original import settings in one click.
- Undo-safe Missing Script Cleaner across the full avatar hierarchy (including disabled objects).
- Duplicate Material Merger that consolidates materials sharing identical shaders, properties, and textures across renderers with Undo support.
- Before / After Snapshot Diff to compare two audit runs side by side.
- Standalone light-mode HTML Diagnostic Report exporter for offline review or client handoff.

============================================================
Note on Texture VRAM vs Crunch Compression
============================================================
Unity Crunch compression shrinks download and disk size, while runtime GPU VRAM depends on resolution and block format (for example, DXT5 at 8 bpp or ASTC 6x6 at 3.56 bpp). Dropping one 4096x4096 DXT5 texture with mipmaps from 4K to 2K lowers GPU VRAM from 21.3 MB to 5.3 MB (75% less). At 1024px ASTC 6x6 on Quest, the same texture drops to 0.59 MB.

============================================================
License
============================================================
- Permitted for personal, commercial, and commission avatar work.
- Do not redistribute, resell, or bundle the tool scripts/packages themselves.
- Pro edition is licensed per user. Lite edition may be shared via the official KitWorks Lab VPM repo link.

Support & VPM Repository: KitWorks Lab (https://kitworks-lab.github.io/vpm/)