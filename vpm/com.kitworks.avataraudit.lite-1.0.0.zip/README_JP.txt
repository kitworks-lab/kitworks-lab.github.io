AvatarAudit for Unity (VRChat Avatars 3.0)
Version 1.0.0 / KitWorks Lab
対応環境: Unity 2022.3 LTS (2022.3.22f1 推奨) / VRCSDK3 未導入でも動作

============================================================
概要
============================================================
VRChat のアバター改変でよくある「なんで Very Poor になったのか分からない」「どのテクスチャが VRAM を食っているのか探すのが面倒」を、Unity エディタ上で1画面にまとめる診断・最適化ツールです。

PC と Android / Quest (Mobile) の両方に対応し、VRChat 公式の Performance Ranking 基準（25項目）で現在値・ランク・上限までの余裕や超過分を一覧表示します。VRCSDK とはリフレクション経由で連携するため、SDKのバージョン差や未導入プロジェクトでもコンパイルエラーになりません。

============================================================
導入方法
============================================================
[方法 A] VCC (VRChat Creator Companion) 経由で導入（推奨）
1. VPM リポジトリ URL を VCC の Settings > Packages > Add Repository に追加、または付属の VPM 用 ZIP を VCC の User Packages フォルダへ展開してください。
2. 対象プロジェクトの Manage Project 画面から AvatarAudit を追加します。

[方法 B] .unitypackage をインポート
1. Unity でアバターのプロジェクトを開きます。
2. 付属の .unitypackage ファイルを Project ウィンドウへドラッグ＆ドロップし、Import を押します。
※ Lite 版から Pro 版へ切り替える場合、Assets/KitWorks/AvatarAuditLite フォルダを削除してから Pro 版を入れるとメニューがすっきりします（残したままでもエラーにはなりません）。

============================================================
使い方
============================================================
1. Unity 上部メニューから以下を開きます。
   - Lite 版: Tools > KitWorks > AvatarAudit Lite
   - Pro 版 : Tools > KitWorks > AvatarAudit Pro
2. 「対象アバター」欄に Hierarchy 上のアバター Root をドラッグ＆ドロップします。
3. 評価プラットフォーム（PC / Android・Quest）を選び、「診断を実行」を押します。
4. ウィンドウ右上の JP / EN ボタンで表示言語をいつでも切り替えられます。

============================================================
主な機能
============================================================
[Lite / Pro 共通]
- PC / Mobile 両対応の VRChat パフォーマンスランク詳細（Triangles, VRAM, SkinnedMesh, Material Slots, Bones, PhysBones 関連4項目, Contacts, Constraints, Animators, Lights, Particles, Bounds など）
- Mesh Read/Write オフによる強制 Very Poor や、Mobile の PhysBone/Constraint ハード上限超過（Quest側で全削除される条件）の警告
- テクスチャ GPU VRAM ランキング（解像度・Mipmap ×1.333・DXT1/DXT5/BC7/ASTC 6x6/RGBA32 の実 bpp で計算、Ping ボタンで即アセット選択）
- Missing Script、壊れたシェーダー（ピンク表示）、空マテリアルスロット、重複マテリアル候補、Humanoid 必須ボーン抜けの検出
- 診断サマリーのクリップボードコピー

[Pro 版のみ]
- 1クリック一括テクスチャ / VRAM 最適化
  プリセット3種（PC バランス 2K/Crunch、PC 軽量 1K/Crunch、Quest/Android 安全 1K/ASTC 6x6）から選び、適用前に削減見込み MB をプレビューできます。
  適用時に元のインポート設定を JSON (Library/KitWorks_AvatarAudit_TextureBackup.json) へ自動保存するため、「元のインポート設定に戻す」ボタンでいつでもロールバックできます。
- Missing Script 一括削除（Ctrl+Z の Undo 対応）
- 重複マテリアル統合（同一シェーダー・テクスチャ・設定のマテリアルを Undo 対応で1つに置換）
- Before / After スナップショット比較（最適化前後のランク変化・VRAM削減量を確認）
- スタンドアロン HTML 診断レポート出力（ブラウザでオフライン閲覧可能）

============================================================
テクスチャ VRAM についての補足
============================================================
Unity の Crunch 圧縮はファイル容量（ダウンロードサイズ）を小さくしますが、VRChat 実行時の GPU VRAM は主に「テクスチャ解像度」と「ブロック形式（DXT1/DXT5/ASTC）」で決まります。
例: 4096x4096 (DXT5, Mipmapあり) 1枚で約 21.3 MB 使いますが、2048x2048 に下げると約 5.3 MB（75%減）、1024x1024 で約 1.3 MB（93.75%減）、Quest向け ASTC 6x6 (1024px) なら約 0.59 MB まで下がります。

============================================================
ライセンス・利用規約
============================================================
- 個人・商用アバター制作、改変作業、受託制作のツールとして自由に利用できます。
- 本ツールのスクリプト・パッケージ自体の再配布、転売、改変後の再販は禁止です。
- Pro 版は購入者ご本人の端末でのみご利用ください（Lite 版は VCC リポジトリ URL の紹介・共有歓迎です）。

サポート / 配布元: KitWorks Lab (https://kitworks-lab.github.io/vpm/)